define(function(require, exports, module) {

    var $ = require("base/zepto");

    return{
        query : function(s) {
            var ret = document.querySelectorAll(s);
            return ret.length > 1 ? ret : ret[0];
        },
        getQuery:function(name,url){
            //参数：变量名，url为空则表从当前页面的url中取
            var u  = arguments[1] || window.location.search,
                reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)"),
                r = u.substr(u.indexOf("\?")+1).match(reg);
            return r!=null?r[2]:"";
        },      
        namespace:function(str) {
            var arr=str.split(',');
            for(var i=0,len=arr.length;i<len;i++){
                // 将命名空间切成N部分, 比如mini、common等
                var arrJ=arr[i].split("."),parent={};
                for(var j = 0,jLen=arrJ.length; j < jLen; j++){
                    var name = arrJ[j],child=parent[name];
                    j===0?eval('(typeof '+name+')==="undefined"?('+name+'={}):"";parent='+name):(parent=parent[name]=(typeof child)==='undefined'?{}:child);
                };
            }
        },
        urlReplace:function(name, param) {
            var r = param.url || location.search.substring(1),
                reg = new RegExp("(^|&)("+name+"=)([^&]*)"),
                content = !param.content ? "" : param.content;
            return r.replace(reg, function(a,b,c,d){return !content ? "" : b+c+content});
        },
        ajaxReq:function(opt, suc, error) {
        	//跳登陆url
        	var _this = this;
            var option = {
                type:"GET",
                url:"",
                data:"",
                dataType:"html",
                timeout:5000
            };
            $.extend(option,opt);
            if(!error) {
                error = function() {}
            }
            $.ajax({
                type:option.type,
                url:option.url,
                data:option.data,
                dataType:option.dataType,
                success:function(data) {
                    if(option.dataType == "json") {
                        data.errCode = parseInt(data.errCode, 10);
                        data.retCode = parseInt(data.retCode, 10);
                    }
                    if(data.errCode == 302){
                    	//跳转登陆态链接
                    	var nowUrl = location.href, bid = _this.getQuery("bid",nowUrl) || 1275000330;
                    	var backUrl = encodeURIComponent("http://weigou.qq.com/prevmbuy/cn/auth/login.xhtml/"+bid+"/"+encodeURIComponent(encodeURIComponent(nowUrl)));
                    	var loginUrl = "http://open.weixin.qq.com/connect/oauth2/authorize?appid=wx8205a9ee3ca50cba&redirect_uri="+backUrl+"&response_type=code&scope=snsapi_base&state=#wechat_redirect";                       
                    	var cancelUrl = encodeURIComponent(nowUrl);
                    	var qqLoginUrl = "http://pt.3g.qq.com/s?aid=touchLogin&t=weigou&bid_code=qqbuyLogin&go_url="+backUrl+"&back_url="+cancelUrl+"&css=http%3A%2F%2F3gimg.qq.com%2Fmobilelife%2Fweigou%2Fwshop%2Fgamma%2Fweigou-order%2Fcss%2Fweigou-login.css&loginTitle=QQ%E7%BD%91%E8%B4%AD&g_ut=2";
                    	switch(data.retCode){
                    	case 1:location.href=loginUrl;break;
                    	case 2:location.href=qqLoginUrl;break;
                    	}
                    }else{
                    	suc(data);
                    }
                },
                error:error
            });
        },
        showAjaxErr:function(json, msg) {
            utils.showBubble(json.msgType ? json.errMsg : msg);
        },
        strReplace:function(template, json) {
            var s = template;
            for(var d in json) {
                var reg = new RegExp("{#"+d+"#}","g");
                s = s.replace(reg, json[d]);
            }
            return s;
        },
        getCookie:function(name) {
            //读取COOKIE
            var reg = new RegExp("(^| )" + name + "(?:=([^;]*))?(;|$)"), val = document.cookie.match(reg);
            return val ? (val[2] ? unescape(val[2]) : "") : null;
        },
        delCookie:function(name, path, domain, secure) {
            //删除cookie
            var value = utils.getCookie(name);
            if(value != null) {
                var exp = new Date();
                exp.setMinutes(exp.getMinutes() - 1000);
                path = path || "/";
                document.cookie = name + '=;expires=' + exp.toGMTString() + ( path ? ';path=' + path : '') + ( domain ? ';domain=' + domain : '') + ( secure ? ';secure' : '');
            }
        },
        setCookie:function(name, value, expires, path, domain, secure) {
            //写入COOKIES
            var exp = new Date(), expires = arguments[2] || null, path = arguments[3] || "/", domain = arguments[4] || null, secure = arguments[5] || false;
            expires ? exp.setTime(exp.getTime() + expires*24*3600*1000) : "";
            document.cookie = name + '=' + escape(value) + ( expires ? ';expires=' + exp.toGMTString() : '') + ( path ? ';path=' + path : '') + ( domain ? ';domain=' + domain : '') + ( secure ? ';secure' : '');
        },
        payDeal:function(json, node) {
            var data = json.data, url;
            // 在线支付
            if (!data.payType) {
                // 财付通
                if(!data.payChannel) {
                    location.href = data.tenpayUrl;
                } else {
                    url = window.basePath+"/cn/minipay/tcallback.xhtml?paySuc=true&dealCode="+data.dealCode+"&feeCash="+data.minipayPo.feeCash+"&t="+ new Date().getTime();
                    // 微支付
                    WeixinJSBridge.invoke('getBrandWCPayRequest',{
                        "appId" : data.minipayPo.appId,             //公众号名称，由商户传入
                        "timeStamp" : data.minipayPo.timeStamp+"",     //时间戳
                        "nonceStr" : data.minipayPo.nonceStr,               //随机串
                        "package" : data.minipayPo.packageStr,
                        "signType" : "SHA1", //微信签名方式:sha1
                        "paySign" : data.minipayPo.sign //微信签名
                    },function(res){
                        node && node.removeClass("btn_disabled");
                        if(res.err_msg == "get_brand_wcpay_request:ok") {
                            location.href = url;
                        }
                    });
                }
            } else {
                location.href = window.basePath + "/cn/deal/codSuc.xhtml?dc=" + data.dealCode + "&suin=" + data.sellerUin + "&" + window.baseParam;
            }
        }
    };
});