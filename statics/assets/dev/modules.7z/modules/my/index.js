/**
 * 个人中心 查询订单列表
 * 页面参数说明
 *      @param bid 商户ID号，对页面没有实际作用，但是后端需要，用作登录使用
 *             index 默认展示哪个tab，默认为0
 */
define(function(require, exports, module) {
    var main = require("base/main"),
        $ = main.$,
        util = main.util,
        bubble = main.bubble,
        doT = main.dot,
        url = main.url,
        fetch = main.request,
        keyMap = main.keyMap,
        store = main.cache,
        pay = require("pay/pay"),
        utils = main.util;

    var params = {}, pageData, cache = new store(keyMap.myCenter),
        statusMap = {
            "WAIT_PAY":"待付款",
            "WAIT_SEND":"待发货",
            "WAIT_RECEIVE":"待收货",
            "ALREADY_CLOSED":"已关闭",
            "ALREADY_DEFEND":"已拒签",
            "DEAL_SUCCESS":"交易成功",
            "REFUND":"退款中",
            "REFUND_SUC":"退款完成",
            "UNKNOW_STATUS":"未知状态",
            "STOREPICKUP_WAIT_CONFIRM":"待店员确认",
            "STOREPICKUP_SUC":"门店取货成功",
            "NEWITEM_WAIT_RECEIVE":"新款预定待发货",
            "REFUND_WAITSELLER_AGREE":"待卖家确认退货",
            "REFUND_WAITBUYER_SEND":"待买家退货",
            "REFUND_WAITSELLER_CONFIRM":"待卖家确认收货",
            "REFUND_CANCEL":"取消退货",
            "REFUND_SUCCESS":"退货完成"
        }, initIndex, sb = bubble.showBubble,cclass="mod-order-tab__item_current";
    function init() {
        var query = util.getQuery,
            bid = query("bid");
        // 默认选中的tab
        initIndex = parseInt(query("index") || 0, 10);
        initIndex = isNaN(initIndex) || initIndex > 2 || initIndex < 0 ? 0 : initIndex;
        // 没有bid
        if(!bid || isNaN(bid)) {
            // 从缓存中拿数据
            try {
                params = JSON.parse(cache.getStore());
            } catch(e) {
                showError("参数错误");
                return;
            }
        } else {
            params.bid = bid;
            params.index = initIndex;
            // 将参数写缓存
            cache.setStore(params, true);
        }
        // 获取数据
        fetchData();
    }
    function fetchData() {
        // 获取数据
        fetch.getPageData({
            key:"getMyIndex",
            data:params,
            callback:renderPage,
            loginKey:"myIndexPage"
        });
    }
    function renderPage(data) {
        pageData = data;
        var tabList = [
            {tabName:"待付款",totalNum:data.allDealCount},
            {tabName:"待收货",totalNum:data.waitPayCount},
            {tabName:"已结束",totalNum:""}],
            tpl = $("#page-tpl").html();
        data.tabList = tabList;
        // 高度和容器高度
        data.height = window.innerHeight+45;
        data.listHeight = data.height - 120;
        var dotTemplate = doT.template(tpl);
        data.initIndex = initIndex;
        $("#container").html(dotTemplate(data));
        data.tabList = null;
        // 渲染tab的订单列表
        renderTabContent();
    }
    function renderTabContent() {
        myorder.init();
    }
    function showError(desc) {
        sb({icon:"warn","text":desc || "网络错误"});
    }






    var myorder = {};

    /**
     * 初始化
     */
    myorder.init = function(){
        var _this = this;
        if(!_this.checkUrl()){
            return;
        }

//        utils.ajaxReq({
//            type:"GET",
//            url: window.basePath + "/cn/my/jsonIndex.xhtml",
//            dataType:"json"
//        },function(json){
//            if(json.errCode == 0 && json.data){
//                _this.initPage(json.data);
//                return true;
//            }else{
//                bubble.showBubble({icon:"warn", text:"页面错误", autoHide:false});
//                return false;
//            }
//        },function(){
//            bubble.showBubble({icon:"warn", text:"页面错误", autoHide:false});
//            return false;
//        });
//        fetch.getPageData({
//            key:"getMyIndex",
//            data:{bid:_this.sellerUin},
//            callback:_this.initPage,
//            context: _this,
//            loginKey:"myIndexPage"
//        });
//
//        // ********************* TEST  ******************************
////        _this.jsonData = {"errCode":"0","newItems":{"totalNum":"0", "dealList":[]}, "waitPayData":{"dealList":[{"dc":"1275000330-20131105-1176795013","dt":"17970","ds":"60","il":[{"din":"1","dsc":"1176795013","ic":"0AF6FE4B0000000104010000348B95D7","itn":"Vero Moda亮面彩条无袖背心裙通勤连衣裙N(黑)|313207099","at": "颜色:010黑|尺码:175/92A/XL","pic":"item-52722E51-0AF6FE4B0000000004010000348B95D7.0.jpg"},{"din":"1","dsc":"1176795013","ic":"0AF6FE4B0000000104010000348B95D7","itn":"Vero Moda亮面彩条无袖背心裙通勤连衣裙N(黑)|313207099","at": "颜色:010黑|尺码:175/92A/XL","pic":"item-52722E51-0AF6FE4B0000000004010000348B95D7.0.jpg"},{"din":"1","dsc":"1176795013","ic":"0AF6FE4B0000000104010000348B95D7","itn":"Vero Moda亮面彩条无袖背心裙通勤连衣裙N(黑)|313207099","at": "颜色:010黑|尺码:175/92A/XL","pic":"item-52722E51-0AF6FE4B0000000004010000348B95D7.0.jpg"},{"din":"1","dsc":"1176795013","ic":"0AF6FE4B0000000104010000348B95D7","itn":"Vero Moda亮面彩条无袖背心裙通勤连衣裙N(黑)|313207099","at": "颜色:010黑|尺码:175/92A/XL","pic":"item-52722E51-0AF6FE4B0000000004010000348B95D7.0.jpg"},{"din":"1","dsc":"1176795013","ic":"0AF6FE4B0000000104010000348B95D7","itn":"Vero Moda亮面彩条无袖背心裙通勤连衣裙N(黑)|313207099","at": "颜色:010黑|尺码:175/92A/XL","pic":"item-52722E51-0AF6FE4B0000000004010000348B95D7.0.jpg"},{"din":"3","dsc":"1176795013","ic":"0AF6FE4B0000000104010000348B95D7","itn":"Vero Moda亮面彩条无袖背心裙通勤连衣裙N(黑)|313207099","at": "颜色:010黑|尺码:175/92A/XL","pic":"item-52722E51-0AF6FE4B0000000004010000348B95D7.0.jpg"}],"pt":"1","sn":"idc测试帐号","su":"1275000330","sc":"1"},{"dc":"1275000330-20131105-1176793071","dt":"17970","ds":"60","il":[{"din":"1","dsc":"1176793071","ic":"0AF6FE4B0000000104010000348B95D7","itn":"Vero Moda亮面彩条无袖背心裙通勤连衣裙N(黑)|313207099","at": "颜色:010黑|尺码:175/92A/XL","pic":"item-52722E51-0AF6FE4B0000000004010000348B95D7.0.jpg"}],"pt":"1","sn":"idc测试帐号","su":"1275000330","sc":"1"},{"dc":"1275000330-20131105-1176795009","dt":"17970","ds":"60","il":[{"din":"1","dsc":"1176795009","ic":"0AF6FE4B0000000104010000348B95D7","itn":"Vero Moda亮面彩条无袖背心裙通勤连衣裙N(黑)|313207099","at": "颜色:010黑|尺码:175/92A/XL","pic":"item-52722E51-0AF6FE4B0000000004010000348B95D7.0.jpg"}],"pt":"1","sn":"idc测试帐号","su":"1275000330","sc":"1"},{"dc":"1275000330-20131105-1176793069","dt":"17970","ds":"60","il":[{"din":"1","dsc":"1176793069","ic":"0AF6FE4B0000000104010000348B95D7","itn":"Vero Moda亮面彩条无袖背心裙通勤连衣裙N(黑)|313207099","at": "颜色:010黑|尺码:175/92A/XL","pic":"item-52722E51-0AF6FE4B0000000004010000348B95D7.0.jpg"}],"pt":"1","sn":"idc测试帐号","su":"1275000330","sc":"1"},{"dc":"1275000330-20131105-1176577839","dt":"17820","ds":"60","il":[{"din":"1","dsc":"1176577839","ic":"0AF6FE4B0000000104010000348B95D7","itn":"Vero Moda亮面彩条无袖背心裙通勤连衣裙N(黑)|313207099","at": "颜色:010黑|尺码:175/92A/XL","pic":"item-52722E51-0AF6FE4B0000000004010000348B95D7.0.jpg"}],"pt":"1","sn":"idc测试帐号","su":"1275000330","sc":"1"},{"dc":"1275000330-20131105-1176643522","dt":"1","ds":"60","il":[{"din":"1","dsc":"1176643522","ic":"0AF6FE4B0000000104010000348C85B0","itn":"测试商品（127）请勿下架","at": "颜色:杏色","pic":"item-52727471-0AF6FE4B0000000004010000348C85B0.0.jpg"}],"pt":"1","sn":"idc测试帐号","su":"1275000330","sc":"1"}],"totalNum":"6"},"waitRecvData":{"dealList":[{"dc":"1275000330-20131105-1176577305","dt":"1","ds":"61","il":[{"din":"1","dsc":"1176577305","ic":"0AF6FE4B0000000104010000348C85B0","itn":"测试商品（127）请勿下架","at": "颜色:杏色","pic":"item-52727471-0AF6FE4B0000000004010000348C85B0.0.jpg"}],"pt":"1","sn":"idc测试帐号","su":"1275000330","sc":"2"}],"totalNum":"1"},"drawback":{"dealList":[],"totalNum":"0"},"end":{"dealList":[{"dc":"1275000330-20131014-1161600713","dt":"1","ds":"64","il":[{"din":"1","dsc":"1161600713","ic":"0AF6FE4B000000010401000033EEC4ED","itn":"sfsdff_test","at": "","pic":"item-5256662A-0AF6FE4B000000000401000033EEC4ED.0.jpg"}],"pt":"1","sn":"idc测试帐号","su":"1275000330","sc":"4"}],"totalNum":"1"}};
       _this.initPage(pageData);
        // ********************* TEST  ******************************
    };
//
    /**
     * 渲染页面
     * @param jsonData
     */
    myorder.initPage = function(jsonData){
        var _this = this;
        _this.jsonData = jsonData;
        _this.pageTpl = $("#page-tpl").html();
        _this.dealTpl = $("#deal-tpl").html();
        _this.statusMap = {
            "WAIT_PAY":"待付款","WAIT_SEND":"待发货","WAIT_RECEIVE":"待收货","ALREADY_CLOSED":"已关闭",
            "ALREADY_DEFEND":"已拒签","DEAL_SUCCESS":"交易成功","REFUND":"退款中","REFUND_SUC":"退款完成",
            "UNKNOW_STATUS":"未知状态","STOREPICKUP_WAIT_CONFIRM":"待店员确认","STOREPICKUP_SUC":"门店取货成功","NEWITEM_WAIT_RECEIVE":"新款预定待发货",
            "REFUND_WAITSELLER_AGREE":"待卖家确认退货","REFUND_WAITBUYER_SEND":"待买家退货","REFUND_WAITSELLER_CONFIRM":"待卖家确认收货","REFUND_CANCEL":"取消退货","REFUND_SUCCESS":"退货完成"
        };
        this.evtConfig = {
            "click":{
                "showDrawList":this.displayDrawList,
                "showBookList":this.displayBookList,
                "confirmRecv":this.confirmReceive,
                "toPay":this.toPay,
                "loadMore":this.loadMore
            },
            "change":{
                "changePay":this.changePay
            }
        };
        // 当前tab序号
        this.curTabIndex = utils.getQuery("index") || 0;
        // 当前tab的页码
        this.curTabPageNum = 1;
        // tab下对应的订单操作和文字
        this.textMap = {
            0:{tabName:"待付款",data:"waitPayDeals"},
            1:{tabName:"待收货",data:"waitRecvSendDeals"},
            2:{tabName:"已结束",data:"finishDeals"}
        };

        //var pageDot = doT.template(_this.pageTpl);
        //$(document.body).prepend(pageDot(_this.jsonData));

        this.initParam();
        this.bindEvent();
    };

    /**
     * 渲染订单列表
     * @returns {boolean}
     */
    myorder.renderDealList = function(){
        var _this = this;

        var    index = _this.curTabIndex,
            dealDot = doT.template(_this.dealTpl),
            dealList = _this.jsonData[_this.textMap[index].data],
            dealHtml="";

        for(var i=0; i<dealList.length; i++){
            var _deal = dealList[i], count=0;
            var date = new Date(_deal.dealCreateTime*1000);
            _deal.month = date.getMonth()+1;
            _deal.day = date.getDate();
            _deal.stateName = this.statusMap[_deal.mobileDealStatus];
            _deal.totalPay = (_deal.totalPay/100).toFixed(2);
            for(var j=0; j<_deal.items.length; j++){
                count += parseInt(_deal.items[j].buyNum, 10);
                _deal.items[j].attrs = _deal.items[j].attr.split("|");
            }
            _deal.totalCount = count;
            dealHtml += dealDot(_deal);
        }
        $("#dealList").html(dealHtml);

        $(".mod-order-list__detail").on("click", $.proxy(_this.toDealDetail, _this));
        //$(".mod-order-good__button").on("touchend", $.proxy(_this.toTenpay, _this));
    };

    /**
     * 校验url
     */
    myorder.checkUrl = function(){
        var _this = this, url = location.href,
            _myIndexCache = new store(keyMap["myIndex"]),
            bid = utils.getQuery("bid", url),
            myIndexCache;
        if(bid){
            _this.sellerUin = bid;
            _myIndexCache.setStore({
                bid : bid
            }, true);
            return true;
        } else {
            try{
                myIndexCache = JSON.parse(_myIndexCache.getStore());
                if(myIndexCache.bid){
                    _this.sellerUin = myIndexCache.bid;
                    return true;
                } else {
                    bubble.showBubble({icon:"warn", text:"链接错误", autoHide:false});
                    return false;
                }
            } catch(e) {
                bubble.showBubble({icon:"warn", text:"链接错误", autoHide:false});
                return false;
            }
        }
    };

    // 初始化node元素
    myorder.initParam = function () {
        var _this = this;
//        // 订单容器
//        this.containerTpl = $("#container-tpl").html();
//        // 退款节点模板
//        this.drawbackTpl = $("#drawback-tpl").html();
//        // 新款预定节点模板
//        this.booknewTpl = $("#booknew-tpl").html();
//        this.noneTpl = $("#none-tpl").html();

        _this.tabNode = $("#tab-list");
        _this.toAddrListNode = $("#toAddrList");
        _this.toCouponListNode = $("#toCouponList");
        _this.backNode = $("#goBack");

        // 选中指定的tab
        _this.tabNode.children().eq(_this.curTabIndex).addClass(cclass);
        myorder.renderDealList();
//        // 当前tab的最大页码
//        this.curTabMaxPage = Math.ceil(window.dealData[this.textMap[this.curTabIndex].data].totalNum/10);
//        // 没有订单时的显示区域的高度
//        this.emptyHeight = window.innerHeight - 150;
//        // 加载内容提示节点
//        this.loadNode = $("#load-more");
//        // 判断是否是从订单详情页点申请退款后跳转回来的
//        this.dback = utils.getQuery("dback") || false;
//        // 渲染默认tab下的订单数据
//        this.renderTabContent();
//        setTimeout(function() {
//            !$.os.android && (document.body.scrollTop = 45);
//        }, 200);
    };

    myorder.bindEvent = function () {
        var _this = this;
        _this.tabNode.find("div").on("touchend", $.proxy(_this.handleTabChange, _this));
        _this.toAddrListNode.on("touchend", function(){
            location.href = basePath + "/wx/addr/addr-list.shtml";
        });
        _this.toCouponListNode.on("touchend", function(){
            location.href = basePath + "/cn/coupon/list.xhtml?bid=" + _this.sellerUin;
        });

        _this.backNode.on("touchstart", $.proxy(_this.goBack,_this));

//        $(".lay_page")[0].addEventListener("click",this, false);
//        document.body.addEventListener("change", this, false);
    };

    myorder.toDealDetail = function(e){
        p = e.target;
        if(p.getAttribute("data-tpurl")){
            location.href = p.getAttribute("data-tpurl");
        }else{
            while(!p.getAttribute("data-dc")){
                p = p.parentNode;
            }
            var _dc = p.getAttribute("data-dc");
            location.href = url.dealDetailPage + "?dc=" + _dc + "&bid=" + this.sellerUin;
        }

    };


    myorder.toTenpay = function(e){
        location.href = e.target.getAttribute("data-tpurl");
    }

    myorder.goBack = function(e){
        location.href = window.basePath+"/wx/index/index.shtml?bid=1002000325";
    }


    /**
     * tab切换事件
     * @param e
     */
    myorder.handleTabChange = function (e) {
        var _this = this, element = e.target, index;
        while(element.tagName != "DIV") {
            element = element.parentNode;
        }
        element = $(element), index = element.attr("index");
        if (element.hasClass(cclass)) {
            return;
        }
        element.addClass(cclass).siblings().removeClass(cclass);

        // reset一堆参数
//        _this.curTabPageNum = 1;
        _this.curTabIndex = index;
        _this.renderDealList();
        //index==0 || $(".mod-new-product-confirm__submit").addClass("qb_none")
//        _this.curTabMaxPage = Math.ceil(window.dealData[_this.textMap[index].data].totalNum/10);
//        _this.renderTabContent();
//        if(_this.curTabMaxPage > 1) {
//            _this.loadNode.html("点击加载更多订单").removeClass("qb_none").css("opacity",1);
//        }
//        location.hash = "";
//        _this.dback = false;
        e.preventDefault();
    };
//
//
//    //**********************************  旧代码   **************************************
//    //**********************************  旧代码   **************************************
//
//    myorder.handleEvent = function(e) {
//        var t = e.type, node = e.target, tag = node.getAttribute("evtTag");
//        if(!tag || !this.evtConfig[t] || !this.evtConfig[t][tag]) {return;}
//        this.evtConfig[t][tag].call(this, node);
//    };
//
//    /**
//     * 渲染订单列表
//     * @param (cacheData) 从服务器加载的订单数据
//     */
//    myorder.renderTabContent = function(cacheData) {
//        var index = this.curTabIndex,
//            data = cacheData || window.dealData[this.textMap[index].data].dealList,
//            totalHtml = [],
//            drawDealList = window.dealData.drawback.dealList,
//            bookList = window.dealData.newItems.dealList;
//        if(this.curTabMaxPage <= 1) {
//            this.loadNode.addClass("qb_none");
//        } else {
//            this.loadNode.html("点击加载更多").removeClass("qb_none");
//        }
//        if(data.length == 0) {
//            if(index == 1) {
//                // 待发货的tab，渲染退款数据
//                drawDealList.length > 0 && totalHtml.push(this.genDrawbackList(drawDealList));
//                // 待发货的tab，渲染新品数据
//                bookList.length > 0 && totalHtml.push(this.genBookList(bookList));
//                if(totalHtml.length > 0) {
//                    $("#itemList").html(totalHtml.join(""));
//                    this.drawNode = $("#drawbackList");
//                    this.bookNewNode = $("#bookList");
//                    this.showDrawbackAni(index);
//                } else {
//                    $("#itemList").html(this.noneTpl.replace(/{#height#}/g, this.emptyHeight).replace(/{#text#}/, this.textMap[index].tabName));
//                }
//            } else {
//                $("#itemList").html(this.noneTpl.replace(/{#height#}/g, this.emptyHeight).replace(/{#text#}/, this.textMap[index].tabName));
//            }
//            return;
//        }
//        totalHtml.push("<div id='normalList'>"+this.genOrderList(data).join("")+"</div>");
//        // 切换tab时，重新渲染，待发货的tab，渲染退款数据
//        if(!cacheData) {
//            totalHtml.push(this.genDrawbackList(drawDealList));
//            totalHtml.push(this.genBookList(bookList));
//        }
//        // 拉取后续页面的数据
//        cacheData ? $("#normalList").append(totalHtml.join("")) : $("#itemList").html(totalHtml.join(""));
//        this.drawNode = $("#drawbackList");
//        this.bookNewNode = $("#bookList");
//        this.showDrawbackAni(index);
//    };
//
//    /**
//     * 退款订单列表
//     * @param data  退款的json数据
//     * @return {Array}
//     */
//    myorder.genDrawbackList = function(data) {
//        var html = [];
//        if(this.curTabIndex == 1 && data && data.length > 0) {
//            html.push(this.drawbackTpl.replace(/{#nodeId#}/, "drawback-node"));
//            html.push("<div class='fn_tuikuan'><div id='drawbackList' class='fn_tuikuan_list "+(this.dback ? 'animate' : 'qb_none')+"'>"+this.genOrderList(data).join("")+"</div></div>");
//        }
//        return html.join("");
//    };
//    /**
//     * 新款预定订单列表
//     * @param data
//     */
//    myorder.genBookList = function(data) {
//        var html = [];
//        if(this.curTabIndex == 1 && data && data.length > 0) {
//            html.push(this.booknewTpl.replace(/{#nodeId#}/, "booknew-node"));
//            html.push("<div class='fn_tuikuan'><div id='bookList' class='fn_tuikuan_list qb_none'>"+this.genOrderList(data).join("")+"</div></div>");
//        }
//        return html.join("");
//    };
//
//    /**
//     * 循环订单列表
//     * @param data
//     * @return {Array}
//     */
//    myorder.genOrderList = function(data) {
//        var d, itemData, itemHtml, totalNum, totalHtml = [], sdc, sd;
//        for(var i=0,l=data.length;i<l;i++) {
//            d = data[i], itemData = d.il, itemHtml = [], totalNum=0, sdc = "";
//            for(var j= 0,len=itemData.length;j<len;j++) {
//                sd = itemData[j];
//                var st = sd.pic, prefix = st.substr(st.lastIndexOf("."), st.length);
//                st = st.replace(prefix, ".80x80"+prefix);
//                itemHtml.push(utils.strReplace(this.itemListTpl, {
//                    "pic":st,
//                    "singleShow":(len == 1 ? "" : "qb_none"),
//                    "itemName":sd.itn,
//                    "attr":(sd.at ? '<p class="qb_fs_s ui_color_weak">'+sd.at+'</p>' : ""),
//                    "singleLi":"single qb_mb10 qb_bfc bfc_f",
//                    "imgClass":"bfc_f"
//                }));
//                sdc += (sd.dsc+"-");
//                totalNum += parseInt(sd.din, 10);
//            }
//            d.sdc = sdc.substr(0, sdc.length - 1);
//            // 是否显示确认收货和查看物流
//            d.receive_show = d.ds == 62 && d.pt == 1 ? "" : "qb_none";
//            // 是否显示付款按钮
//            d.pay_show = d.ds == 60 ? "" : "qb_none";
//            // 图片列表
//            d.itemPicList = itemHtml.join("");
//            d.totalCount = totalNum;
//            d.stateName = this.statusMap[d.sc];
//            d.totalPay = (d.dt/100).toFixed(2);
//            d.show = d.ds == 61 || d.ds == 71 ? "" : "qb_none";
//            totalHtml.push(utils.strReplace(this.containerTpl, d));
//            itemHtml = null;
//        }
//        return totalHtml;
//    };
//
//
//    /**
//     * @desc 加载更多
//     */
//    myorder.loadMore = function() {
//        var _this = this;
//        _this.curTabPageNum++;
//        _this.loadNode.html("加载中...");
//        // 加载后面页面内容 currTab = 4表示加载退款更多，这期先不做
//        utils.ajaxReq({
//            url:window.basePath+"/cn/my/next.xhtml?"+window.baseParam,
//            dataType:"json",
//            data:{
//                currTab:_this.curTabIndex,
//                pageNo:_this.curTabPageNum
//            }
//        }, function(json) {
//            _this.loadNode.html("点击加载更多订单");
//            if(!json.errCode) {
//                if(_this.curTabPageNum == _this.curTabMaxPage) {
//                    _this.loadNode.html("没有更多记录了").animate({
//                        "opacity":0
//                    },200, "ease-out", function() {
//                        $(this).addClass("qb_none")
//                    });
//                }
//                this.dback = false;
//                json.dealList.length > 0 && _this.renderTabContent(json.dealList);
//            } else if(json.errCode == 260) {
//                _this.curTabPageNum--;
//                utils.showBubble("登录超时");
//            } else {
//                utils.showAjaxErr(json,"");
//                _this.curTabPageNum--;
//                _this.loadNode.html("加载失败，请重试");
//            }
//        });
//    };
//
//    // 展开退款列表
//    myorder.displayDrawList = function(n) {
//        var node = $(n);
//        this.drawNode.toggleClass("qb_none");
//        if(node.hasClass("arrow_up")) {
//            node.removeClass("arrow_up").addClass("arrow_down");
//        } else {
//            node.removeClass("arrow_down").addClass("arrow_up");
//        }
//    };
//    // 展开
//    myorder.displayBookList = function(n) {
//        var node = $(n);
//        this.bookNewNode.toggleClass("qb_none");
//        if(node.hasClass("arrow_up")) {
//            node.removeClass("arrow_up").addClass("arrow_down");
//        } else {
//            node.removeClass("arrow_down").addClass("arrow_up");
//        }
//    };
//
//    /**
//     * @desc 从订单详情跳转回来，滚动到退款的动画
//     * @param index tab序号
//     */
//    myorder.showDrawbackAni = function(index) {
//        var _this = this;
//        if(!_this.dback || index != 1) {
//            return;
//        }
//        var t = 0, node = $("#drawback-node");
//        if(node.length == 0) {return;}
//        var st = setInterval(function() {
//            document.body.scrollTop = t+100;
//            t += 100;
//            if(t >= node.offset().top - 125) {
//                clearInterval(st);
//                _this.drawNode.addClass("show");
//            }
//        },1);
//    };
//
//    /**
//     * 去付款
//     * @param node
//     */
//    myorder.toPay = function(node, pc) {
//        pc = pc ? pc : 0;
//        var url = {
//            0:window.basePath+"/cn/pay/topay.xhtml",
//            1:window.basePath+"/cn/minipay/generateMinipay.xhtml?"+window.baseParam
//        }
//        if(!url[pc]) {return;}
//        utils.ajaxReq({
//            url:url[pc],
//            data:{
//                dc:node.getAttribute("dc"),
//                t:+new Date()
//            },
//            dataType:"json"
//        }, function(json) {
//            if(!json.errCode) {
//                if(!pc) {
//                    location.href = json.data.payUrl;
//                } else {
//                    json.data.payType = 0;
//                    json.data.payChannel = 1;
//                    json.data.dealCode = node.getAttribute("dc");
//                    utils.payDeal(json);
//                }
//            } else if(json.errCode == 260) {
//                utils.showBubble("登录超时");
//            } else {
//                utils.showAjaxErr(json,"请求遇到错误，请重试。");
//            }
//        }, function() {
//            utils.showBubble("请求遇到了点问题，请重试。");
//        });
//    };
//
//    /**
//     * @desc 确认收货
//     * @param node
//     */
//    myorder.confirmReceive = function(node) {
//        utils.ajaxReq({
//            url:node.getAttribute("url"),
//            dataType:"json"
//        }, function(json) {
//            if(!json.errCode) {
//                utils.showBubble("确认收货成功");
//                $(node).addClass("qb_none");
//            } else if(json.errCode == 260) {
//                utils.showBubble("登录超时");
//            } else {
//                utils.showAjaxErr(json, "确认收货失败，请重试。");
//            }
//        }, function() {
//            utils.showBubble("请求遇到了点问题，请重试。");
//        })
//    };
//    // 切换支付方式
//    myorder.changePay = function(node) {
//        var v = parseInt(node.value, 10);
//        if(v != -1) {
//            utils.showBubble(v == 0 ? "正在前往财付通支付中心，请稍后": "正在调用微信支付");
//            this.toPay(node, v);
//        }
//    };

    exports.init = init;
});
