/**
 * @desc 省市区联动模块
 *      province
 *      city
 *      region
 */
define(function() {

});