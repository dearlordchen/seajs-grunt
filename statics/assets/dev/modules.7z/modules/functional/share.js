/**
 * @desc 微信分享模块，自定义分享
 */
define(function() {

})