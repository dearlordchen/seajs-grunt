/**
 * 优惠信息选择组件
 *      return {
 *          init:优惠初始化方法
 *          reCountPromote:重新计算满减
 *      }
 */
define(function(require, exports, module) {
    var $ = require("base/zepto");
    var option = {
        // 满立减优惠
        promoteList:"",
        // 优惠券列表
        couponList:"",
        // 展示方式--->  0:列表 1:展示最优惠的一条
        showType:1,
        // 展示模板
        template:"",
        // 购买数量，用于判断是否满足优惠条件
        buyCount:"",
        // 付款价格，用于判断是否满足优惠条件
        price:"",
        // 订单来源
        comeFrom:0,
        // 当前选择的运费
        curShipFee:0
        }, promoteIndex, promote = {};
    // 初始化函数，配置信息
    function promoteInit(config) {
        $.extend(option, config);
        // 利用当前价格和数量，建立优惠索引
        promoteIndex = {
            "0":{"op":"-","num":option.price},   // num用来和优惠的值进行比较，判断是否满足条件
            "1":{"op":"*","num":option.buyCount},
            "num":option.price
        };
        scanCoupon();
        scanPromote(true);
        return promote;
    }
    // 扫描优惠券列表
    function scanCoupon() {
        var coupon = option.couponList, ft;
        if(coupon.length == 0) {return;}
        // 取优惠的第一个记录
        coupon.sort(function(a,b) {return a.amount < b.amount;});
        ft = coupon[0];
        promote.couponId = ft.id;
        promote.couponAmount = -parseInt(ft.amount, 10);
        promote.couponHtml = option.template.replace(/{#promoteDesc#}/,(ft.amount/100).toFixed(2)+"元优惠券").replace(/{#tag#}/, "coupon").replace(/{#free#}/,'').replace(/{#amount#}/, ft.amount).replace(/{#id#}/,ft.id);
        // 重写满减金额
        promoteIndex["0"].num = promoteIndex.num = option.price + promote.couponAmount < 1 ? 1 : option.price + promote.couponAmount;
        return promote;
    }
    // 扫描满立减优惠列表
    function scanPromote(init) {
        var proList = option.promoteList, countResult = [], first;
        // 初始调用
        if(init) {
            if(option.comeFrom !== 1) {
                // 删除掉第一条记录
                proList.splice(0,1);
            } else if(proList.length > 0) {
                proList[0].desc = "收藏商品减免运费";
                // 打一个导购的标记
                proList[0].guide = true;
            }
        } else {
            promote.reduce = 0;
            promote.isFreeFee = false;
            promote.promoteId = 0;
        }
        // 没有满减条件
        if(proList.length == 0) {return;}
        proList.forEach(function(pro) {
            var result = comparePromote(pro);
            // 如果包邮，则将邮费价格加入到优惠金额中
            pro.recudeMoney = result.reduce;
            if(result.freeFee) {
                pro.recudeMoney = result.reduce + -option.curShipFee;
            }
            pro.freeFee = result.freeFee;
            // 如果优惠金额是大于0的
            pro.recudeMoney && countResult.push(pro);
            result = null;
        });
        // 没有符合当前价格的满减优惠
        if(countResult.length == 0) {
            return promote;
        }
        // 依据减的金额进行排序
        countResult.sort(function(a,b) {return a.recudeMoney > b.recudeMoney});
        first = countResult[0];
        // 记录优惠信息
        promote.reduce = parseInt(first["recudeMoney"],10);
        promote.isFreeFee = first.freeFee;
        promote.promoteId = first.id;
        init && (promote.promoteHtml = option.template.replace(/{#free#}/, first.freeFee).replace(/{#promoteDesc#}/, first.desc).replace(/{#id#}/, first.id).replace(/{#tag#}/, "promote").replace(/{#amount#}/, first.recudeMoney));
        return promote;
    }
    // 比较满减优惠金额
    function comparePromote(rule) {
        var cnds = rule.cnd,
            reduce,
            favor = 0,
            freeFee = false;
        cnds.forEach(function(cnd, seq) {
            // 规则存在
            if(cnd != "0") {
                // 判断当前优惠和用户购买的价格，符合优惠条件
                if(promoteIndex[seq].num >= parseInt(cnd,10)) {
                    // 包邮
                    if(rule.feeCarriage[0] !== "0") {
                        freeFee = true;
                    }
                    reduce = rule.reduce;
                    reduce.forEach(function(item, index) {
                        if(item !== "0" && item !== "0.0") {
                            // 计算减去的金额，例如减30元，原价200元，计算的过程为
                            // -(200 - eval(200 - 30))
                            // -(200 - eval(200*0.9))
                            favor = -(promoteIndex.num - eval(promoteIndex.num + promoteIndex[index].op + item));
                        }
                    });
                }
            }
        });
        return {
            freeFee:freeFee,
            reduce:favor
        };
    }
    module.exports = {
        init:promoteInit,
        recountPromote:scanPromote
    };
});