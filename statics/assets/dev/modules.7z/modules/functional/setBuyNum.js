/**
 * 商品详情页购买数量事件和交互控制
 */
define(function(require) {
    var main = require("base/main"),
        bubble = main.bubble;
    function initInput(config) {
        var option = {
            "minus":"",
            "plus":"",
            "input":""
        }
    }
});