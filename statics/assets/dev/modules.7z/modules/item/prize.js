/**
 * 导购和扫码购抽奖模块
 */
define(function() {

});