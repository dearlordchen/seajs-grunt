define(function (require, exports, module) {
    var main = require("base/main"),
        favorModule = require("item/favor"),
        focus = require("functional/focus"),
        $ = main.$,
        utils = main.util,
        bubble = main.bubble,
        dialog = main.dialog,
        doT = main.dot,
        url = main.url,
        fetch = main.request,
        keyMap = main.keyMap,
        store = main.cache,
        error = main.error;


    var saler = {}, pageData, qrDialogNode, loopTimes = 0, favorData, closeStatus, sb = bubble.showBubble,
        rewardConfig = {
        "1":"恭喜你，在参与微购物百万免单活动中，获得一部iPad mini，请返回微信对话窗口，查看领奖方式",
        "2":"恭喜您，获得微购物发现之旅【免单大奖】，可现场挑选一件1500元以内的免单专款，请联系店员完成兑奖。",
        "3":"恭喜你，在参与微购物百万免单活动中，获得Q币奖励，请返回微信对话窗口，查看领奖方式",
        "no":"小伙伴，还差一点就中奖了，再加把劲！惊喜就在身边！",
        "passion":"亲爱的小伙伴，首次收藏商品才有抽奖资格哦！收藏多多，机会多多，试试收藏其他商品吧！"
    };

    saler.init = function () {
        var _this = this;
        if (!_this.checkUrl()) {
            return;
        }
        _this.container = $("#container");

        // 兼容android 2.3 获取高宽值问题
        if ($.os.android && parseInt($.os.version, 10) < 4){
            _this.defaultWidth = window.innerWidth;
            _this.loopCount = 0;
            _this.loopCheck();
        } else {
            _this.initPage();
        }
    };
    saler.loopCheck = function (){
        var _this = this;
        if(_this.loopCount < 40 && window.innerWidth == _this.defaultWidth){
            _this.loopCount++;
            setTimeout(function(){
                _this.loopCheck();
            }, 50);
        } else {
            _this.initPage();
        }
    };


    /**
     * 校验url
     */
    saler.checkUrl = function () {
        var _this = this, url = location.href,
            _detailCache = new store(keyMap["itemDetail"]),
            bid = utils.getQuery("bid", url),
            ic = utils.getQuery("ic", url);
        if (bid && ic) {
            _this.sellerUin = bid;
            _this.itemCode = ic;
            _detailCache.setStore({
                "bid": bid,
                "ic": ic
            }, true);
            return true;
        } else {
            var detailCache;
            try {
                detailCache = JSON.parse(_detailCache.getStore());
                if (detailCache.bid && detailCache.ic) {
                    _this.sellerUin = detailCache.bid;
                    _this.itemCode = detailCache.ic;
                    return true;
                } else {
                    error.showErrorPage();
                    _this.showError("链接错误");
                    return false;
                }
            } catch (e) {
                error.showErrorPage();
                _this.showError("链接错误");
                return false;
            }
        }
    };
    // ajax请求商详信息
    saler.initPage = function () {
        var _this = this;
        fetch.getPageData({
            key: "getItemDetail",
            data: {bid: _this.sellerUin, ic: _this.itemCode},
            callback: _this.renderPage,
            context: _this,
            loginKey: "itemDetailPage"
        });
    };
    saler.statusMap = {
        "1": "商品缺货",
        "2": "商品下架",
        "3": "商品不存在"
    };
    // 渲染商详主页面
    saler.renderPage = function (jsonData) {
        var _this = this;
        pageData = jsonData;
        _this.sellerUin = jsonData.bid;
        _this.windowHeight = window.innerHeight + 45;
        jsonData.height = _this.windowHeight;
        jsonData.imgHeight = document.body.clientWidth - 50;
        jsonData.guideUrl = window.basePath + "/cn/guide/index.xhtml/guideInfo/" + _this.sellerUin + "/" + _this.itemCode;
        jsonData.btnText = jsonData.prizeList && jsonData.prizeList.length > 0 ? "马上兑奖" : "一键购买";
        jsonData.itemStatusText = _this.statusMap[jsonData.itemStatus];
        jsonData.prizeId = (jsonData.prizeList && jsonData.prizeList.length > 0 && jsonData.prizeList[0].prizeId) || -1;
        // 渲染商品
        var tpl = $("#single-item-tpl").html(), dot = doT.template(tpl);
        _this.container.html(dot(jsonData));
        // 将bid写cookie
        utils.setCookie("bid", jsonData.bid, 0.03125, "/", ".weigou.qq.com");
        jsonData = null;
        // 初始化参数
        _this.initParam();
        // 初始化事件
        _this.bindEvent();
        // 初始化收藏
        _this.initFavor();
    };

    saler.initParam = function () {
        var _this = this;
        _this.itemCache = [];
        _this.curIndex = -1;
        _this.curIc = pageData.itemId;

        // 购买数量
        _this.buyNum = 1;
        // 获取当前的库存数量
        _this.curStock = 0;
        // 存放已选择的属性，用于属性关系互斥的判断
        _this.matchProperty = [];
        // 已经选择的属性
        _this.selectedCount = 0;
        // sku组合列表数组
        _this.propList = [];
        // 已选择的属性(格式化的)
        _this.buyProperty = "";
        // 提示错误信息
        _this.errorMsg = "";
        _this.pageNode = $("#page");
        _this.dialogNode = $("#dialog");
        _this.maskNode = $("#mask");
        // 商品详情浮层模板
        _this.itemTpl = doT.template($("#item-tpl").html());
        // 弹二维码的模板
        _this.qrCodeTpl = doT.template($("#qrCode-tpl").html());

        // 裁剪图片
        _this.imgNode = $(".mod-single-product__img");
        _this.imgSize = (document.body.clientWidth-50);
        fillPic(_this.imgNode, _this.imgSize, _this.imgSize);
    };
    saler.bindEvent = function () {
        $(window).on("bubble:show", function () {
            window.bubbleStatus = true;
        });
        $(window).on("bubble:close", function () {
            window.bubbleStatus = false;
        });
        this.container.on("tap change", $.proxy(this.handleEvent, this));

//        // 图片滑动浏览
//        this.bindScroll();
    };

    saler.handleEvent = function(e) {
        var node = $(e.target), et = node.attr("et"), type = e.type, _this = this;
        if(et) {
            if(et.indexOf(type) != -1) {
                dispatchEvent();
            }
        } else {
            // 向上找一级，找不到就结束
            node = node.parent(), et = node.attr("et");
            if(!et) {return;}
            if(et.indexOf(type) != -1) {
                dispatchEvent();
            }
        }
        e.stopPropagation();
        function dispatchEvent() {
            _this[et.split(":")[1]](node);
        }
    };

    /**
     * 跳转导购页
     * @param e
     */
    saler.toGuidePage = function () {
        if (window.bubbleStatus) {
            return;
        }
        window.location.href = pageData.guideUrl;
    };

//    saler.bindScroll = function(){
//        $.scroll = $(".mod-new-product__box").scroll({
//            contentWrap:".mod-new-product__img-box",
//            autoGen:false,
//            pageWidth : (document.body.clientWidth-50) + "px",
//            cycle : true,
//            loadImg:true,
//            imgProp:"lazy",
//            setWidth:true,
//            onProcess:function(index) {},
//            onImgLoad:function(node) {
//                // 图片加载后，裁剪图片
////                fillPic(node,document.body.clientWidth-50);
//            }
//        });
//    };

    saler.initFavor = function () {
        var _this = this;
        favorModule.favorInit({
            highlightClass: "mod-single-product__star-icon_current",
            btn: "#favor-node",
            focused:pageData.focus,
            wxId:pageData.bidWxId,
            beforeFavor: function () {
                // 如果在状态配置中，则认为商品已经无法收藏
                if (_this.statusMap[pageData.itemStatus]) {
                    _this.showError(_this.statusMap[pageData.itemStatus]);
                    return false;
                }
                return {
                    itemCode: pageData.itemId,
                    pic: pageData.itemPics[0]
                }
            },
            beforeCancel: function () {
                return {itemCode: pageData.itemId}
            },
            onFavor:function(json) {
                var content = "";
                favorData = json;
                // 弹出二维码
                if(json.needDimCode) {
                    content = _this.qrCodeTpl({
                        qrCode:url.qrCode+"?itemCode="+json.itemCode+"&sellerUin="+json.sellerUin+"&guideBuyerUin="+json.buyerUin,
                        top:"请向店员出示本页面",
                        sub:"可享受免费邮寄和优先留货等服务"
                    });
                    !qrDialogNode ? (qrDialogNode = _this.qrDialog(content)): qrDialogNode.setContent(content);
                    closeStatus = false;
                    _this.loopAsk();
                } else {
                    // 判断是否在活动期间，或者是是否有活动抽奖资格
                    if(json.active) {
                        // 显示抽奖结果
                        _this.showReward();
                    }
                }
            }
        });
    };
    /**
     * 轮询店员扫码
     */
    saler.loopAsk = function() {
        var _this = this,
            param = {
                "guideSellerUin":favorData.sellerUin,
                "guideBuyerUin":favorData.buyerUin,
                "itemCode":favorData.itemCode,
                "t":+new Date()
            };
        loopTimes = 0;
        startAsk();
        // 准备开始轮询
        function startAsk() {
            if(loopTimes >= 500) {
                return;
            }
            loopTimes++;
            var callback = arguments.callee;
            utils.ajaxReq({
                url:url.qrScan,
                data:param,
                dataType:"json"
            }, function(json) {
                if(!json.errCode) {
                    if(json.data.scaned) {
                        // 更新浮层显示的内容
                        qrDialogNode.setContent($("#scanSuc-tpl").html());
                        // 5s后隐藏dialog框
                        setTimeout(function() {
                            _this.closeQrDialog();
                        },5000);
                    } else {
                        // 间隔2s进行下一次询问
                        setTimeout(function() {
                            callback();
                        }, 2000);
                    }
                }
            });
        }
    };

    saler.showError = function (desc) {
        sb({icon: "warn", text: desc || "网络错误"});
    };

    /**
     * 打开微信相册
     * @param e
     */
    saler.handleOpenImgs = function () {
        if (window.bubbleStatus) {
            return;
        }
        pageData.itemPics && showPic(pageData.itemPics);
        function showPic(list) {
            WeixinJSBridge.invoke('imagePreview', {
                    'current': list[0],
                    'urls': list}
            );
        }
    };

    /**
     * 浮层弹出
     */
    saler.openDialog = function () {
        var _this = this;
        // android
        if ($.os.android && parseInt($.os.version, 10) < 4) {
            _this.dialogNode.css({"top": "0px", "position": "relative"});
        } else {
            _this.dialogNode.css({"top": this.windowHeight, "height": ($.os.android ? _this.windowHeight : window.innerHeight) - 10, "position": "fixed"});
        }
        // android4以下系统部使用动画
        if ($.os.android && parseInt($.os.version) < 4) {
            _this.pageNode.addClass("ui-d-n");
            _this.dialogNode.css({
                "position": "relative",
                "top": "0px",
                "z-index": 999
            }).removeClass("ui-d-n");
            _this.maskNode.removeClass("ui-d-n");
        } else {
            _this.dialogNode.removeClass("ui-d-n");
            _this.maskNode.removeClass("ui-d-n");
            _this.dialogNode.animate({
                "-webkit-transform": "translate3d(0px," + -_this.windowHeight + "px,0px)"
            }, 300, "linear", function () {
            });
        }
    };
    /**
     * 浮层隐藏
     */
    saler.handleCloseDialog = function () {
        var _this = this;
        // android4以下系统部使用动画
        if ($.os.android && parseInt($.os.version) < 4) {
            _this.maskNode.addClass("ui-d-n");
            _this.dialogNode.addClass("ui-d-n");
            _this.pageNode.removeClass("ui-d-n");
        } else {
            _this.dialogNode.animate({
                "-webkit-transform": "translate3d(0px,0px,0px)"
            }, 300, "linear", function () {
                _this.maskNode.addClass("ui-d-n");
            });
        }
    };
    /**
     * 打开浮层事件
     * @param e
     */
    saler.handleOpenDialog = function (node) {
        if (window.bubbleStatus) {
            return;
        }
        if(node.hasClass("mod-new-product-confirm__submit_disabled")) {return;}
        var _this = this, index = 0;
        // 活动期间免单的
        if(pageData.prizeId != -1) {
            _this.exchangeFree(node);
            return;
        }
        if (!_this.itemCache[_this.curIndex]) {
            _this.curIndex = index;

            // 参数恢复
            // 购买数量
            _this.buyNum = 1;
            // 获取当前的库存数量
            _this.curStock = 0;
            // 存放已选择的属性，用于属性关系互斥的判断
            _this.matchProperty = [];
            // 已经选择的属性
            _this.selectedCount = 0;
            // sku组合列表数组
            _this.propList = [];
            // 已选择的属性(格式化的)
            _this.buyProperty = "";
            // 提示错误信息
            _this.errorMsg = "";
            // 限购数量
            _this.buyLimit = null;
            _this.renderDialogPage();
        } else {
            _this.openDialog();
        }
    };
    /**
     * 渲染浮层内容
     */
    saler.renderDialogPage = function () {
        var _this = this;
        // 有打开过浮层，直接拿缓存
        if (!_this.itemCache[_this.curIndex]) {
            sb({autoHide:false});
            utils.ajaxReq({
                url: url.itemAttr,
                data: {ic: _this.curIc, bid: _this.sellerUin, t: +new Date()},
                dataType: "json"
            }, function (json) {
                bubble.closeBubble();
                if (!json.errCode) {
                    var data = json.data;
                    _this.itemCache[_this.curIndex] = data;
                    _this.buyLimit = parseInt(data.buyLimit);
                    _this.curStock = !data.totalStock ? 0 : parseInt(data.totalStock);
                    $.each(data.availSku, function (key) {
                        _this.propList.push(key);
                    });
                    _this.renderDialogProp();
                    _this.openDialog();
                } else {
                    setTimeout(function() {
                        _this.showError("请求出错");
                    }, 250);
                }
            }, function () {
                bubble.closeDialog();
                setTimeout(function() {
                    _this.showError();
                }, 250);
            });
        } else {
            _this.renderDialogProp();
            _this.openDialog();
        }
    };
    /**
     * 渲染浮层中的属性
     */
    saler.renderDialogProp = function () {
        var _this = this,
            data = _this.itemCache[_this.curIndex],
            skus = data.sku, errNotify = [], matchObj = {};
        data.propList = [];

        skus.forEach(function (sku, index) {
            var obj = {pName: sku.pName, pList: []};
            sku.pList.forEach(function (it) {
                var temp = {};
                temp.key = sku.pName + ":" + it;
                temp.sname = it;
                temp.className = sku.pList.length === 1 ? "current" : '';
                obj.pList.push(temp);
            });
            data.propList.push(obj);
            if (sku.pList.length == 1) {
                // 目的是只保存第一个只有一个属性的属性项作为后续的匹配
                if (!matchObj["key"]) {
                    matchObj["key"] = sku.pName + ":" + sku.pList[0];
                    matchObj["index"] = index;
                    matchObj["propName"] = sku.pName;
                }
                _this.matchProperty[index] = sku.pName + ":" + sku.pList[0];
                _this.selectedCount++;
            } else {
                errNotify.push(sku.pName);
            }
        });
        _this.errorMsg = "请选择" + errNotify.join("/");
        // 非android或者android4.0以上系统
        data.innerStyle = 'height:' + (($.os.android ? _this.windowHeight : window.innerHeight) - 158) + 'px;';
        if (!$.os.android || parseInt($.os.version) >= 4) {
            data.innerStyle += 'overflow-y:scroll;';
        }
        data.imgSrc = pageData.itemPics[0];
        $("#item-container").html(_this.itemTpl(data));

        // 展示属性的节点列表
        _this.pNodeList = $(".mod_property");
        _this.buyNode = $("#weixin-buy");
        //商品缺货
        if (_this.itemCache[_this.curIndex].itemState != "2") {
            _this.buyNode.html("暂时缺货").addClass("btn_disabled");
        }
        // 存在单个属性的情况
        matchObj["key"] && _this.loopProp(matchObj["key"], matchObj["index"], matchObj["propName"]);
        matchObj = null;
        $(".mod-new-product-detail__title").on("tap", $.proxy(_this.handleCloseDialog, _this));
        $(".mod_property span").on("tap", $.proxy(_this.handleProperty, _this));
        $("#buyNum").on("input", $.proxy(_this.handleInput, _this));
        $(".minus").on("tap", $.proxy(_this.handleBtnNum, _this));
        $(".plus").on("tap", $.proxy(_this.handleBtnNum, _this));
        _this.buyNode.on("tap", $.proxy(_this.handleBuy, _this));
    }
    /**
     * 购买支付
     */
    saler.handleBuy = function () {
        if (window.bubbleStatus) {
            return;
        }
        var callback = arguments.callee;
        // 未关注商家
        if (!pageData.focus) {
            focus.focusInit("购买商品，需要关注该商户，是否立即关注?", pageData.bidWxId, function () {
                pageData.focus = true;
                // 调用一下自己，继续下单
                callback();
            });
            return;
        }
        var _this = this;
        if (_this.buyNode.hasClass("btn_disabled")) {
            return;
        }
        if (_this.curStock > 0 && _this.itemCache[_this.curIndex].sku.length > 0 && !_this.buyProperty) {
            _this.showError(_this.errorMsg);
            return;
        }
        sb({text:"努力加载中...",autoHide:false});
        var _coCache = new store(keyMap["confirmOrder"]);
        _coCache.setStore({
            "attr": _this.buyProperty,
            "bc": _this.buyNum,
            "ic": _this.curIc,
            "bid": _this.sellerUin,
            "hcod": 1,
            "comeFrom": 0
        }, true);
        location.href = url.confirmOrderPage;
    }
    /**
     * 绑定属性筛选事件
     * @param e
     */
    saler.handleProperty = function (e) {
        if (window.bubbleStatus) {
            return;
        }
        var p = $(e.target);
        if (p.hasClass("current") || p.hasClass("disabled")) {
            return;
        }
        p.addClass("current").siblings().removeClass("current");
        var parent = p.parent();
        this.loopProp(p.attr("data-value"), parent.attr("index"), parent.attr("skuName"));
    };
    /**
     * 循环属性项
     * @param key   选中的属性值 颜色:红色
     * @param index 序号
     * @param propName  属性名 颜色
     */
    saler.loopProp = function (key, index, propName) {
        var availAttr = [], flag = true, _this = this, cache = _this.itemCache[_this.curIndex];
        // 选择的是颜色属性，展示对应的图片
        if(propName == "颜色" && cache.colorImage[key]) {
            $("#property-img").attr("src", cache.colorImage[key]);
        }
        // 统计已选择的数量，不存在的时候记录
        if (!_this.matchProperty[index]) {
            _this.selectedCount++;
        }
        _this.matchProperty[index] = key;
        availAttr[index] = key;
        $.each(_this.itemCache[_this.curIndex].sku, function (index, item) {
            var pName = item.pName, pList = item.pList, skuGroup, propArr, node = _this.pNodeList.eq(index), spans = node.find("span");
            if (pName !== propName) {
                $.each(pList, function (seq, prop) {
                    skuGroup = pName + ":" + prop;
                    propArr = [];
                    propArr.push(skuGroup);
                    $.each(_this.matchProperty, function (k, v) {
                        if (v && v.match(/.*(?=:)/)[0] != pName) {
                            propArr.push(v);
                        }
                    });
                    $.each(_this.propList, function (tk, tv) {
                        flag = true;
                        flag = propArr.every(function (it) {
                            return tv.indexOf(it) !== -1;
                        });
                        if (flag) {
                            return false;
                        }
                    });
                    flag ? spans.eq(seq).removeClass("disabled") : spans.eq(seq).addClass("disabled");
                });
            }
        });
        _this.statisticSelected();
    };
    /**
     * 统计已选择的属性
     */
    saler.statisticSelected = function () {
        var _this = this, stock, left;
        // 没有选完
        if (_this.selectedCount != _this.itemCache[_this.curIndex].sku.length) {
            return;
        }
        var rule = _this.matchProperty.join("|");
        _this.buyProperty = rule;
        stock = _this.itemCache[_this.curIndex].availSku[rule];
        if (stock) {
            $("#buyNum").val(1);
            left = stock.stockCount;
            $("#stock-num").html(left);
            _this.curStock = parseInt(left, 10);
            $("#price").html("&yen;" + (stock.stockPrice / 100).toFixed(2));
        }
    };
    /**
     * 购买数量事件处理
     * @param e
     */
    saler.handleInput = function (e) {
        var inputNode = $(e.target), val = inputNode.val(), _this = this;
        if (val && isNaN(val)) {
            inputNode.val(1);
            _this.showError("只能输入数字");
        } else if (!val || val <= 0) {
            inputNode.val(1);
            _this.showError("至少购买一件");
        } else if (/\d+\.\d*/.test(val)) {
            inputNode.val(parseInt(val, 10));
            _this.showError("只能输入整数");
        } else if (val > this.curStock) {
            _this.showError("超出库存限制");
            inputNode.val(this.curStock);
            this.buyNum = this.curStock;
        } else if (this.buyLimit && val > this.buyLimit) {
            _this.showError("超出限购数量");
            inputNode.val(this.buyLimit);
            this.buyNum = this.buyLimit;
        } else if (val > 50) {
            _this.showError("超出数量");
            if (this.curStock > 50) {
                inputNode.val(50);
                this.buyNum = 50;
            } else {
                inputNode.val(this.curStock);
                this.buyNum = this.curStock;
            }
        } else {
            this.buyNum = val;
        }
    };
    /**
     * 增减两个按钮事件
     */
    saler.handleBtnNum = function (e) {
        if (window.bubbleStatus) {
            return;
        }
        var _this = this, node = $(e.target), tag = node.attr("tag"), inputNode = $("#buyNum"), val = inputNode.val() * 1;
        if (!val) {
            return;
        } else if (isNaN(val)) {
            inputNode.val(1);
        } else if (val == 1 && tag == "sub") {
            _this.showError("至少购买一件");
            return;
        } else if (tag == "add") {
            if (this.curStock > 50 && val >= 50) {
                _this.showError("超出数量");
                return;
            } else if (this.buyLimit && val == this.buyLimit) {
                _this.showError("超出限购数量");
                return;
            } else if (val == this.curStock) {
                _this.showError("超出库存限制");
                return;
            }
        }
        val = tag == "sub" ? val - 1 : val * 1 + 1;
        inputNode.val(val);
        this.buyNum = val;
    };

    /**
     * 店员二维码浮层
     * @param content
     * @returns {{setContent: Function, hideBtn: Function, showBtn: Function, hide: Function, show: Function}}
     */
    saler.qrDialog = function(content) {
        var _this = this, tpl = $("#favorTips-tpl").html();
        _this.container.append(tpl.replace(/{#content#}/, content));
        var contentNode = $("#dialog-content"), btnNode = $("#dialog-btn"), dialogNode = $("#favor-dialog");
        return {
            setContent:function(ct) {
                contentNode.html(ct);
                this.show();
                return this;
            },
            hideBtn:function() {
                btnNode.addClass("ui-d-n");
                return this;
            },
            showBtn:function() {
                btnNode.removeClass("ui-d-n");
                return this;
            },
            hide:function(callback) {
                // 需要的时候调用回调函数
                callback && callback();
                dialogNode.addClass("ui-d-n");
                return this;
            },
            show:function() {
                dialogNode.removeClass("ui-d-n");
                return this;
            }
        }
    };

    /**
     * 关闭二维码浮层
     */
    saler.closeQrDialog = function() {
        // 停止轮询，传递了callback，认为是免单兑奖
        loopTimes = 500;
        // 在活动期间，点关闭后要抽奖，再次点关闭才真正关闭浮层，使用closeStatus变量来区分状态
        if(favorData && favorData.active && !closeStatus) {
            this.showReward();
        } else {
            favorData && sb({icon:"success", text:"收藏成功"});
            qrDialogNode.hide();
            favorData = null;
        }
    };
    // 显示抽奖符层
    saler.showReward = function() {
        var rewardTpl = doT.template($("#reward-tpl").html()),
            html = rewardTpl({
                "text":"抽奖中...",
                "reward":"<p>请您耐心等待......</p><br/>"
            });
        !qrDialogNode ? qrDialogNode = this.qrDialog(html) : qrDialogNode.setContent(html);
        closeStatus = true;
        setTimeout(function() {
            var lrv = favorData.lotteryResultVo, key = lrv.canLottery ? (lrv.award ? lrv.level : "no") : "passion";
            qrDialogNode.setContent(rewardTpl({
                "text":lrv.award ? "中奖啦！！！" : "很遗憾！！！",
                "reward":rewardConfig[key]
            }));
        }, 2000);
    };
    /**
     * 活动期间选择免单券
     */
    saler.setItemFree = function(node) {
        var value = parseInt(node.val(), 10);
        pageData.prizeId = value;
        // 选择不使用
        if(value == -1) {
            $("#buy-now").html("一键购买");
            $("#price-node").html('<span class="mod-single-product__dollor">&yen;</span>'+(pageData.itemPrice/100).toFixed(2));
        } else {
            $("#buy-now").html("马上兑奖");
            $("#price-node").html("免单");
        }
    };
    /**
     * 兑换免单
     */
    saler.exchangeFree = function(node) {
        var _this = this;
        dialog.showDialog({
            text:"免单券使用后无法取消，是否确定使用！",
            rightFn:function() {
                setOrder();
            }
        });
        function setOrder() {
            // 把按钮置灰
            node.addClass("mod-new-product-confirm__submit_disabled");
            sb({autoHide:false});
            utils.ajaxReq({
                url:url.freeItem,
                dataType:"json",
                type:"POST",
                data:{
                    "ic":pageData.itemId,
                    "prizeId":pageData.prizeId,
                    "bid":_this.sellerUin
                }
            }, function(json) {
                bubble.closeBubble();
                node.removeClass("mod-new-product-confirm__submit_disabled");
                if(!json.errCode) {
                    var data = json.data, content = _this.qrCodeTpl({
                        qrCode:url.findQrCode+"?buyerOpenId="+data.buyerOpenId+"&prizeId="+data.prizeId+"&sellerUin="+data.sellerUin,
                        top:"请向店员出示本页面，即可兑奖商品",
                        sub:"请务必让现场店员扫码！因自行操作造成的免单凭证失效，由用户承担损失。"
                    });
                    !qrDialogNode ? (qrDialogNode = _this.qrDialog(content)): qrDialogNode.setContent(content);
                    // 免单券已使用，将节点从列表中remove掉
                    var optNode = $("#"+data.prizeId), selNode = optNode.parent();
                    optNode.remove();
                    // 判断是否还有剩余的免单券，没有的话，把免单列表屏蔽
                    if(selNode.children().length == 1) {
                        selNode.parent().remove();
                        // 改回去状态
                        _this.prizeId = -1;
                        $("#buy-now").html("一键购买");
                        $("#price-node").html('<span class="mod-single-product__dollor">&yen;</span>'+(pageData.itemPrice/100).toFixed(2));
                    } else {
                        selNode.children()[1].selected = true;
                    }
                    _this.findLoop(data);
                } else {
                    _this.showError("兑奖失败");
                }
            }, function() {
                bubble.closeBubble();
                _this.showError()
            });
        }
    };
    // 活动期间扫码购轮询免单
    saler.findLoop = function(json) {
        var _this = this
        loopTimes = 0;
        startAsk();
        // 准备开始轮询
        function startAsk() {
            if(loopTimes >= 500) {
                return;
            }
            loopTimes++;
            var callback = arguments.callee;
            utils.ajaxReq({
                url:url.findLoopScan,
                data:{prizeId:json.prizeId},
                dataType:"json"
            }, function(json) {
                if(!json.errCode) {
                    // 已经扫描
                    if(json.data.scaned) {
                        _this.closeQrDialog();
                    } else {
                        setTimeout(function() {
                            callback();
                        }, 2000);
                    }
                }
            });
        }
    };
    /**
     * 裁剪图片模块
     */
    var imgReady = (function () {
        var list = [], intervalId = null,
        // 用来执行队列
            tick = function () {
                var i = 0;
                for (; i < list.length; i++) {
                    list[i].end ? list.splice(i--, 1) : list[i]();
                };
                !list.length && stop();
            },
        // 停止所有定时器队列
            stop = function () {
                clearInterval(intervalId);
                intervalId = null;
            };
        return function (url, ready, load, error) {
            var check, width, height, newWidth, newHeight,
                img = new Image();
            img.src = url;
            // 如果图片被缓存，则直接返回缓存数据
            if (img.complete) {
                ready(img.width, img.height);
                load && load(img.width, img.height);
                return;
            };
            // 检测图片大小的改变
            width = img.width;
            height = img.height;
            check = function () {
                newWidth = img.width;
                newHeight = img.height;
                // 如果图片已经在其他地方加载可使用面积检测
                if (newWidth !== width || newHeight !== height || newWidth * newHeight > 1024) {
                    ready(newWidth, newHeight);
                    check.end = true;
                };
            };
            check();
            // 加载错误后的事件
            img.onerror = function () {
                error && error();
                check.end = true;
                img = img.onload = img.onerror = null;
            };
            // 完全加载完毕的事件
            img.onload = function () {
                load && load(img.width, img.height);
                !check.end && check();
                img = img.onload = img.onerror = null;
            };
            // 加入队列中定期执行
            if (!check.end) {
                list.push(check);
                // 无论何时只允许出现一个定时器，减少浏览器性能损耗
                if (intervalId === null) intervalId = setInterval(tick, 40);
            };
        };
    })();

    var fillPic = function(node, w, h) {
        var temp;
        imgReady(node.attr("src"), function(width,height) {
            // 计算图片和容器的宽高比
            if(w/h >= width/height) {
                temp = parseInt(height/width * w,10);
                node.css({
                    "width":w+1,
                    "height":temp
                });
            } else {
                temp = parseInt(width/height*h,10);
                node.css({
                    "width":temp+1,
                    "height":h,
                    "margin-left":parseInt((w - temp)/2,10)
                });
            }
        });
    };

    module.exports = saler;
});