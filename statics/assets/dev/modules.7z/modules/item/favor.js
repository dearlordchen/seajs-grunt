/**
 * 导购和扫码购收藏和取消收藏模块
 *  @params
 *          btn : 收藏按钮，css选择器格式 [必选]
 *          highlightClass : 按钮收藏和取消收藏高亮的样式
 *          focused : 用户的关注状态，默认为true
 *          wxId : 要关注的微信ID
 *          onFavor : 收藏成功后的回调函数
 *          beforeFavor : 收藏前的回调函数，主要是用于传递收藏的参数
 *          beforeCancel : 取消收藏前的回调函数，用于传递取消收藏的参数
 */
define(function (require, exports) {
    var main = require("base/main"),
        $ = main.$,
        focusModule = require("functional/focus"),
        util = main.util,
        url = main.url,
        bubble = main.bubble;
    var option = {
        btn: "",                     // 收藏按钮
        highlightClass:"",              // 按钮高亮的样式
        focused: true,                 // 用户的关注状态
        wxId: "",                    // 需要关注的微信ID
        justFavor:true,              // 是否只是收藏
        onFavor: function () {          // 收藏后的回调函数
            return true;
        },
        beforeFavor:function() {return true;},        // 发请求前的回调，用于写参数
        beforeCancel:function() {return true;}       // 取消收藏前的回调
    }, evtConfig = {
        "addFavor": addFavor,
        "cancel": cancelFavor
    };

    function initFavor(config) {
        if (!config) {
            return;
        }
        $.extend(option, config);
        bindEvent();
    }

    function bindEvent() {
        $(option.btn).on("tap", handleEvent);
    }

    function handleEvent(e) {
        if(window.bubbleStatus){return;}
        var node = $(e.target), tag;
        // 再该状态下认为是已经收藏过的
        if (!node.hasClass(option.highlightClass)) {
            tag = "addFavor";
        } else {
            tag = "cancel";
        }
        evtConfig[tag](node);
        // 阻止冒泡
        e.stopPropagation();
    }

    function addFavor(node) {
        var callback = arguments.callee;
        // 未关注
        if (!option.focused) {
            focusModule.focusInit("收藏商品，需要关注该商户，是否立即关注?", option.wxId, function () {
                option.focus = true;
                callback(node);
            });
            return;
        }
        // 收藏前的回调
        var params = option.beforeFavor(node);
        // 如果回调函数返回true，则认为可以继续往下走
        if(params) {
            bubble.showBubble({text:"努力加载中...",autoHide:false});
            sendReq(url.favorItem, params, function(json) {
                bubble.closeBubble();
                if(!json.errCode) {
                    node.addClass(option.highlightClass);
                    // 调用回调函数
                    option.onFavor(json.data);
                } else {
                    showError("收藏失败");
                }
            });
        }
    }

    function sendReq(url, data, callback) {
        util.ajaxReq({
            url: url,
            data: data,
            dataType: "json"
        }, callback, function () {
            showError();
        })
    }

    function cancelFavor(node) {
        var param = option.beforeCancel(node);
        sendReq(url.cancelFavor, param, function(json) {
            if(!json.errCode) {
                // 修改状态
                bubble.showBubble({icon:"success", text:"已取消收藏"});
                node.removeClass(option.highlightClass);
            } else {
                bubble.showBubble({icon:"warn", text:"取消收藏失败"});
            }
        });
    }
    function showError(desc) {
        bubble.showBubble({icon:"warn",text:desc||"网络错误"});
    }
    exports.favorInit = initFavor;
});