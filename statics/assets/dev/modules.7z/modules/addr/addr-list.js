define(function(require, exports, module) {
    var main = require("base/main"),
        $ = main.$,
        utils = main.util,
        bubble = main.bubble,
        dialog = main.dialog,
        doT = main.dot,
        url = main.url,
        fetch = main.request,
        keyMap = main.keyMap,
        store = main.cache,
        error = main.error;
    var g = {}, sb = bubble.showBubble;
    // 请求收货地址列表
    g.init = function(){
        var _this = this;
        if(!_this.checkUrl()){
            error.showErrorPage();
            return;
        }
        _this.initAddrId = _this.getParam("addrId");
        _this.getParam("cf");
        fetch.getPageData({
            key : "getAddrList",
            data : {bid:_this.sellerUin},
            callback : _this.renderAddrList,
            context : _this,
            loginKey:"addrListPage"
        });
    };

    /**
     * 校验url
     */
    g.checkUrl = function(){
        var _this = this;
        _this.sellerUin = _this.getParam("bid");
        if(!_this.sellerUin){
            _this.showError("链接错误");
            return false;
        }
        return true;
    };

    // 从url或缓存中取参数
    g.getParam = function (paramName){
        var url = location.href,
            _aeCache = new store(keyMap["addrList"]),
            _param = utils.getQuery(paramName, url),
            aeCache;
        if(_param){
            try{
                aeCache = JSON.parse(_aeCache.getStore()) || {};
                aeCache[paramName] = _param;
                _aeCache.setStore(aeCache, true);
            } catch(e) {
            }
        } else {
            try{
                aeCache = JSON.parse(_aeCache.getStore());
                if(aeCache[paramName]){
                    _param = aeCache[paramName];
                }
            } catch(e) {
            }
        }
        return _param;
    };

    g.initParams = function () {
        var _this = this;
        _this.touchNode = _this.spx = _this.spy = _this.delNode = '';

        // 初始化当前选中的收货地址
        _this.lastChosed = _this.ulNode.children()[0];
        if(_this.initAddrId){
            // 移动到第一个节点
            var initAddrNode = _this.ulNode.children('li[adid="'+_this.initAddrId+'"]');
            if(initAddrNode.length > 0){
                initAddrNode.remove();
                _this.ulNode.prepend(initAddrNode[0]);
                _this.lastChosed = _this.ulNode.children('li[adid="'+_this.initAddrId+'"]')[0];
            }
        }
        _this.adid = _this.lastChosed.getAttribute("adid");
        $(_this.lastChosed).children("i.mod-pay-list__item-check").addClass("mod-pay-list__item-check_selected");

        // 事件config
        _this.evtConfig = {
            "chose": _this.handleChose,
            "edit": _this.handleEdit,
            "del": _this.handleDelete,
            "touchstart": _this.handleStart,
            "touchend": _this.handleEnd
        };
        // 存缓存的key值
        _this.lkey = "saler-confirm";
        _this.initPageNode();
        _this.bindEvent();
    };

    // 渲染收货地址列表
    g.renderAddrList = function(jsonData){
        var _this = this, dotTpl = doT.template($("#addr-tpl").html()), ulNode = $("#addr-list"), html;
        _this.ulNode = ulNode;
        ulNode.prepend(dotTpl(jsonData));
        _this.initParams();
        // 在微购物上没有地址，但是在拍拍或者网购上有收货地址的，提示用户需要导入
        if(jsonData.addressList.length == 0 && jsonData.boundPaipaiAddrCount > 0) {
            dialog.showDialog({
                text:"检测到您绑定的QQ号，在拍拍/QQ网购上有条收货地址信息，是否导入？",
                rightFn:function() {
                    // 用户允许导入
                    sb({text:"正在导入...",autoHide:false});
                    utils.ajaxReq({
                        url:url.importAddr,
                        dataType:"json"
                    }, function(json) {
                        bubble.closeBubble();
                        if(!json.errCode) {
                            // 将返回的结果列表渲染后append到页面中
                            html = dotTpl({addressList:json.data.boundList});
                            $(html).insertBefore($(".add-addr"));
                            _this.lastChosed = ulNode.children().eq(0);
                            _this.lastChosed.find("i").eq(0).addClass("mod-pay-list__item-check_selected");
                            _this.adid = _this.lastChosed.attr("adid");
                        } else {
                            _this.showError("导入失败");
                        }
                    }, function() {
                        bubble.closeBubble();
                        _this.showError();
                    });
                }
            });
        }
    };

    // 初始化页面dom节点相关
    g.initPageNode = function() {
        var _this = this;
        $("#page").css("min-height", (window.innerHeight+45)+"px").removeClass("qb_none");
        // 页面callback参数写缓存
        if (window.callback != '') {
            window.sessionStorage.setItem(_this.lkey, window.callback);
        }
    };
    g.bindEvent = function () {
        this.ulNode.on("touchstart", $.proxy(this.handleEvent, this));
        this.ulNode.on("touchend", $.proxy(this.handleEvent, this));
        this.ulNode.on("touchmove", $.proxy(this.handleMove, this));
        $("#complete").on("click", $.proxy(this.completeChose, this));
        $("#backto").on("click", $.proxy(this.backTo, this));
        $("#toAdd").on("touchend", $.proxy(this.toAdd, this));
    };

    g.toAdd = function(){
        if(this.ulNode.children().length >= 11){
            this.showError("地址最多10个");
            return;
        }
        location.href = url.addrEditPage + "&bid=" + this.sellerUin + "&addrId=-1";
    };

    // 处理事件
    g.handleEvent = function (e) {
        var type = e.type, node = e.target, tag = node.getAttribute("tag");
        // 不处理click事件
        if (type.indexOf("touch") == -1) {
            return;
        }
        if (!tag) {
            // 找上一级节点，如果还是没有tag，就返回
            node = node.parentNode;
            tag = node.getAttribute("tag");
            if (!tag) {
                return;
            }
        }
        g.evtConfig[type].apply(this, [node, e]);
    };
    // touchstart事件
    g.handleStart = function (node, e) {
        var _this = this, evt = e.changedTouches[0];
        _this.spy = evt.clientY;
        _this.spx = evt.clientX;
        if (node.tagName != "LI") {
            return;
        }
        // 如果已经有一个删除按钮被打开
//        if(_this.touchNode.delStatus == "open") {
        if(_this.touchNode && _this.touchNode.delStatus == "open") {
            _this.closeDelete();
            _this.touchNode = _this.delNode = _this.editNode = '';
            return;
        }
        $(node).addClass("mod-pay-list__item_active");
        // 记录当前操作的节点信息
        _this.touchNode = node;
        _this.delNode = node.querySelector("span");
        _this.editNode = node.querySelector("[tag='edit']");
    };
    // 处理真正的事件
    g.handleEnd = function (node, e) {
        var _this = this, evt = e.changedTouches[0], tag = node.getAttribute("tag"), epy, epx;
        $(node).removeClass("mod-pay-list__item_active");
        epy = evt.clientY;
        epx = evt.clientX;
        // 用户手指滑动横竖着滑动超过10像素，认为用户不是点击操作，前提条件是点击的是列表元素
        if (tag == "chose" && (Math.abs(epy - _this.spy) > 10 || Math.abs(epx - _this.spx) > 10 || !_this.touchNode)) {
            return;
        }
        // 如果用户的手指移动了
        _this.evtConfig[tag].call(_this, node);
    };
    // 选中节点
    g.handleChose = function () {
        var _this = this;
        $(_this.lastChosed).find('i.mod-pay-list__item-check').removeClass("mod-pay-list__item-check_selected");
        $(_this.touchNode).find('i.mod-pay-list__item-check').addClass("mod-pay-list__item-check_selected");
        _this.adid = _this.touchNode.getAttribute("adid");
        _this.lastChosed = _this.touchNode;
        _this.touchNode.delStatus = "close";
    };
    // 跳转编辑页
    g.handleEdit = function (node) {
        location.href = url.addrEditPage + "&addrId=" + node.parentNode.getAttribute("adid") + "&bid=" + this.sellerUin;
    };
    // 删除收货地址
    g.handleDelete = function (node) {
        var _this = this, pNode = node.parentNode, ul = _this.ulNode[0], childs;
        $.ajax({
            url:fetch.addToken(url.deleteAddr,"ls"),
            type:"GET",
            data:{
                addrId:pNode.getAttribute("adid"),
                bid: _this.sellerUin,
                ajax:true
            },
            dataType:"json",
            success: function(json) {
                // 删除成功
                if(!json.errCode && json.data=="success") {
                    $(pNode).on("webkitTransitionEnd", function() {
                        ul.removeChild(pNode);
                        childs = ul.children;
                        // 剩下的收货地址多于一个，才做此操作
                        if(childs.length > 1) {
                            // 判断删除的节点是否是当前选中的
                            if(pNode.getAttribute("adid") == _this.adid) {
                                _this.touchNode = ul.children[0];
                                _this.handleChose();
                            } else {
                                _this.touchNode = null;
                            }
                        } else {
                            // 标识收货地址已经被删除完毕，点完成按钮的时候，跳转至新增页
                            _this.delOver = true;
                        }
                    });
                    pNode.style.cssText = "-webkit-transition:opacity 400ms ease-in;opacity:0";
                }
            },
            error : function(){
                alert("fail");
            }
        });
    };
    // 处理滑动删除事件
    g.handleMove = function (e) {
        var evt = e.changedTouches[0], _this = this, disx;
        // 没有设置
        if(!_this.touchNode || !_this.delNode) {
            return;
        }
        disx = _this.spx - evt.clientX;
        if (disx > 20 && _this.touchNode.delStatus != "open") {
            $(_this.delNode).removeClass("qb_none");
            setTimeout(function () {
                // 标识状态
                _this.touchNode.delStatus = "open";
                _this.delNode.style.cssText = "-webkit-transition:width 200ms ease-in-out;width:55px;z-index:999;";
            }, 10);
        }
        if (disx <= -10) {
            _this.closeDelete();
        }
    };
    /**
     * 关闭列表中的删除按钮
     */
    g.closeDelete = function () {
        var _this = this;
        $(_this.delNode).addClass("qb_none");
        _this.delNode.removeAttribute("style");
        _this.touchNode.delStatus = "close";
    };
    g.completeChose = function() {
        var _this = this;
        // 展示loading
        sb({autoHide:false});
        setTimeout(function() {
            // 已经被删完了，跳转到新增页
            if(_this.delOver || _this.ulNode.children().length === 1) {
                location.href = url.addrEditPage + "&bid=" + _this.sellerUin;
            } else {
                _this.toPrePage(true);
            }
        }, 1000);
    };
    g.backTo = function() {
        sb({autoHide:false});
        // 返回到订单确认页
        setTimeout(function() {
            g.toPrePage();
        }, 800);
    };

    g.toPrePage = function(isSaveOperate){
        var _this = this, _alCache = new store(keyMap["addrList"]),
            addrListCache, preLink = document.referrer;
        try{
            addrListCache = JSON.parse(_alCache.getStore());
            if(addrListCache.cf){
                switch(addrListCache.cf){
                    case keyMap["confirmOrder"]:
                        preLink = url.confirmOrderPage;
                        if(isSaveOperate){
                            var _coCache = new store(keyMap["confirmOrder"]),
                                confirmOrderCache = JSON.parse(_coCache.getStore()) || {};
                            confirmOrderCache.adid = _this.adid;
                            _coCache.setStore(confirmOrderCache, true);
                        }
                        break;
                }
            }
        } catch(e) {
            toPreLink();
        }
        _alCache.delStore();
        toPreLink();
        function toPreLink(){
            location.href = preLink;
        }
    };
    g.showError = function(desc) {
        setTimeout(function() {
            sb({icon:"warn",text:desc||"网络错误"});
        }, 250);
    }
    module.exports = g;
});