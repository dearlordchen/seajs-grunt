define(function(require, exports, module) {
    var main = require("base/main"),
        $ = main.$,
        utils = main.util,
        bubble = main.bubble,
        dialog = main.dialog,
        doT = main.dot,
        url = main.url,
        fetch = main.request,
        keyMap = main.keyMap,
        store = main.cache,
        error = main.error;

    var g = {};

    g.init = function() {
        var _this = this;
        if(!_this.checkUrl()){
            error.showErrorPage();
            return;
        }

        _this.getParam("cf");
        _this.addrId = _this.getParam("addrId");
        _this.isUpdate = _this.addrId && _this.addrId!='-1';
        fetch.getPageData({
            key : "getAddrById",
            data : _this.isUpdate ? {addrId:_this.addrId, bid:_this.sellerUin} : {bid:_this.sellerUin},
            callback : _this.renderPage,
            context : _this,
            loginKey:"addrEditPage",
            addToken:true,
            tokenType:"ls"
        });
    };

    // 从url或缓存中取参数
    g.getParam = function (paramName){
        var url = location.href,
            _aeCache = new store(keyMap["addrEdit"]),
            _param = utils.getQuery(paramName, url),
            aeCache;
        if(_param){
            try{
                aeCache = JSON.parse(_aeCache.getStore()) || {};
                aeCache[paramName] = _param;
                _aeCache.setStore(aeCache, true);
            } catch(e) {
            }
        } else {
            try{
                aeCache = JSON.parse(_aeCache.getStore());
                if(aeCache[paramName]){
                    _param = aeCache[paramName];
                }
            } catch(e) {
            }
        }
        return _param;
    };

    /**
     * 校验url
     */
    g.checkUrl = function(){
        var _this = this;
        _this.sellerUin = _this.getParam("bid");
        if(!_this.sellerUin){
            bubble.showBubble({icon:"warn", text:"链接错误"});
            return false;
        }
        return true;
    };

    g.renderPage = function(jsonData){
        var _this = this, addrTpl = $("#addr-tpl").html();
        jsonData.addrId = _this.isUpdate ? _this.addrId : -1;
        jsonData.height = window.innerHeight+45;
        jsonData.update = _this.isUpdate;
        jsonData.show = jsonData.city && jsonData.city.areaList.length > 0;
        // 后台有问题，港澳台无法保存市地址，所以在这里做兼容
        if(jsonData.province && jsonData.province.provinceId > 30) {
            jsonData.city = {cityId:jsonData.province.cityList[0].cityId};
        }
        var dot = doT.template(addrTpl);
        $("#container").html(dot(jsonData));
        // 记录省ID
        _this.provId = jsonData.province ? jsonData.province.provinceId*1 : -1;
        _this.initParams();
    };

    g.initParams = function () {
        var _this = this;
        // 列表节点
        _this.provinceNode = $("#province");
        _this.cityNode = $("#city");
        _this.regionNode = $("#regionId");
        _this.completeNode = $("#complete");
        _this.provinceList = [
            {"pname": "北京", "pid": 0},
            {"pname": "天津", "pid": 1},
            {"pname": "上海", "pid": 2},
            {"pname": "重庆", "pid": 3},
            {"pname": "河北省", "pid": 4},
            {"pname": "河南省", "pid": 5},
            {"pname": "黑龙江省", "pid": 6},
            {"pname": "吉林省", "pid": 7},
            {"pname": "辽宁省", "pid": 8},
            {"pname": "山东省", "pid": 9},
            {"pname": "内蒙古省", "pid": 10},
            {"pname": "江苏省", "pid": 11},
            {"pname": "安徽省", "pid": 12},
            {"pname": "山西省", "pid": 13},
            {"pname": "陕西省", "pid": 14},
            {"pname": "甘肃省", "pid": 15},
            {"pname": "浙江省", "pid": 16},
            {"pname": "江西省", "pid": 17},
            {"pname": "湖北省", "pid": 18},
            {"pname": "湖南省", "pid": 19},
            {"pname": "贵州省", "pid": 20},
            {"pname": "四川省", "pid": 21},
            {"pname": "云南省", "pid": 22},
            {"pname": "新疆省", "pid": 23},
            {"pname": "宁夏省", "pid": 24},
            {"pname": "青海省", "pid": 25},
            {"pname": "西藏省", "pid": 26},
            {"pname": "广西省", "pid": 27},
            {"pname": "广东省", "pid": 28},
            {"pname": "福建省", "pid": 29},
            {"pname": "海南省", "pid": 30},
            {"pname": "台湾", "pid": 31},
            {"pname": "香港", "pid": 32},
            {"pname": "澳门", "pid": 33}
        ];
        // 直辖市对应的city对象
        _this.directCity = {
            "0":40000,
            "1":100,
            "2":200,
            "3":300
        };
        // 请求参数配置
        _this.reqConfig = {
            "city":{
                "url":url.getCityList,
                "fn":_this.setCity,
                "param":"pvid"
            },
            "area":{
                "url":url.getAreaList,
                "fn":_this.setArea,
                "param":"ctid"
            }
        };
        // 表单校验规则
        _this.formRule = {
            "name": {reg: /^[\u0391-\uFFE5a-zA-Z]+$/, required: true, maxLen: 30, minLen: 1, msg:"收货人"},
            "address": {reg: /.+/,dByte: true, required: true, maxLen: 254, minLen: 1, msg:"收货地址"},
            "mobile": {reg: /^(1[3584]\d{9})$/,required: true, minLen: 5, msg:"联系电话"}
        };
        // 省市区的校验
        _this.areaPass = {
            "province":-1,
            "city":-1,
            "regionId":-1,
            "hasArea":true
        };
        _this.errMsg = "";
        // 请求参数
        _this.formParams = ["name", "pvid", "ctid", "regionId", "address", "mobile", "addrId"];
        _this.initPageNode();
    };
    // 初始化页面html元素节点状态
    g.initPageNode = function() {
        var _this = this;
        if(_this.provId < 4) {
            // 4个直辖市，没有市的概念，隐藏
            _this.cityNode.addClass("ui-d-n");
        }
        // 港澳台隐藏区
        if(_this.provId > 30) {
            _this.regionNode.addClass("ui-d-n");
        }
        _this.initProvince();
        _this.bindEvent();
    };
    g.initProvince = function () {
        var _this = this;
        var opts = '<option value="-1">选择省</option>';
        this.provinceList.forEach(function (item) {
            opts += '<option value="'+item.pid+'" '+(item.pid == _this.provId ? "selected" : '')+'>'+item.pname+'</option>';
        });
        // 如果是更新收货地址
        _this.isUpdate && (_this.areaPass = {
            "province":_this.provId,
            "city":_this.cityNode.val(),
            "regionId":_this.regionNode.val(),
            "hasArea":true
        });
        _this.provinceNode.html(opts);
    };
    g.bindEvent = function() {
        $("#container").on("input tap change", this.handleEvent);
    };
    g.handleEvent = function(e) {
        var node = e.target, et = node.getAttribute("et"), type = e.type;
        // 节点有对应的事件响应
        if(et) {
            if(et.indexOf(type) != -1) {
                dispatchEvent();
            }
        } else {
            // 向上查找父级元素，找不到即止
            node = node.parentNode, et = node.getAttribute("et");
            if(!et) {return;}
            if(et.indexOf(type) != -1) {
                dispatchEvent();
            }
        }
        function dispatchEvent() {
            var fn = et.split(":")[1];
            // 调用对应的函数
            g[fn].call(g, node);
        }
    };
    /**
     * 处理省市县联动
     * @param node
     */
    g.handleSelect = function(node) {
        var _this = this, tag = node.getAttribute("tag"), value = parseInt(node.value, 10), param = {}, obj, ap = _this.areaPass;
        // 将当前选择的地区信息写入到对象中
        ap[node.id] = node.value;
        // 选择的是区一级，不需要再执行后续内容
        if(!tag){
            // 校验表单
            _this.validateForm();
            return;
        }
        _this.setBtnStatus(false);
        // 直辖市，直接取ctid来请求区列表
        if(tag == "city" && value < 4 && value >= 0) {
            tag = "area";
            value = _this.directCity[value];
            _this.cityNode.addClass("ui-d-n");
            // 用于设置提交表单值
            _this.setContent(_this.cityNode, [{id:value,name:""}],"选择市");
            _this.cityNode.val(value);
        }
        obj = _this.reqConfig[tag];
        // 如果选择的是省，则隐藏区的节点
        if(tag == "city") {
            _this.cityNode.addClass("ui-d-n");
            ap.city = -1;
            ap.regionId = -1;
        } else if(tag == "area") {
            ap.regionId = -1;
            // 如果选择的是港澳台，则不再请求区的列表
            if(ap.province > 30) {
                _this.validateForm();
                return;
            }
        }
        _this.regionNode.addClass("ui-d-n");
        if(value == -1 || !value) {_this.validateForm();return;}
        param[obj.param] = value;
        utils.ajaxReq({
            url:obj.url,
            data:param,
            dataType:"json"
        }, function(json) {
            if(!json.errCode) {
                obj.fn.apply(_this, [json.data, value]);
            } else {
                _this.showError("请求遇到错误");
            }
        }, function() {
            _this.showError("网络错误");
        });
    };
    g.setCity = function(json, pvId) {
        var _this = this;
        if(json.length == 0) {
            this.validateForm();
            return;
        }
        _this.cityNode.removeClass("ui-d-n");
        // 几个直辖市
        _this.setContent(_this.cityNode, json, pvId < 4 ? "选择区" : "选择市");
    };
    g.setArea = function(json) {
        var _this = this;
        if(json.length == 0) {
            this.validateForm();
            return;
        }
        _this.regionNode.removeClass("ui-d-n");
        _this.setContent(_this.regionNode, json, "选择区");
    };
    // 设置省市区列表内容
    g.setContent = function(node, content, first) {
        var opts = '<option value="-1">'+first+'</option>';
        content.forEach(function(item) {
            opts += '<option value="'+item.id+'">'+item.name+'</option>';
        });
        node.html(opts);
        // 校验表单
        this.validateForm();
    };
    // 弹出确认符层
    g.toHistory = function() {
        var _this = this;
        dialog.showDialog({
            text:"确认要放弃此次编辑？",
            context:_this,
            leftFn:_this.cancelOperate,
            rightFn:_this.sureOperate
        });
    };
    g.submitForm = function(node) {
        var _this = this;
        if($(node).hasClass("mod-pay__complete_disable")) {
            // 两种提示状态都没有，认为用户尚未填写信息
            if(!_this.errMsg && !_this.listError && !_this.isUpdate) {
                _this.showError("您还未填写地址哦")
            } else if(_this.errMsg) {
                _this.showError(_this.errMsg);
            } else if(_this.listError) {
                _this.showError(_this.listError);
            }
            return;
        }
        bubble.showBubble({autoHide:false});
        var _params={}, i, _pname;
        for(i=0; i<_this.formParams.length; i++){
            _pname = _this.formParams[i];
            _params[_pname] = $("[name="+_pname+"]").val();
        }
        utils.ajaxReq({
            url: fetch.addToken(url.editAddr,"ls"),
            type:"POST",
            data:_params,
            dataType:"json"
        }, function(json) {
            if(!json.errCode) {
                _this.addrId = json.data.addressId;
                _this.toPrePage(true);
            } else {
                bubble.closeBubble();
                setTimeout(function(){
                    bubble.showBubble({icon:"warn", text:"请求出错"});
                }, 300);
            }
        }, function() {
            bubble.closeBubble();
            setTimeout(function(){
                bubble.showBubble({icon:"warn", text:"网络错误"});
            }, 300);
        });
    };
    g.cancelOperate = function() {
        dialog.closeDialog();
    };
    g.sureOperate = function() {
        // 返回到来源页
        var _this = this;
        bubble.showBubble({autoHide:false});
        setTimeout(function() {
            _this.toPrePage();
        }, 500);
    };
    g.toPrePage = function(isSaveOperate){
        var _this = this, _aeCache = new store(keyMap["addrEdit"]),
            addrEditCache, preLink = url.addrListPage+"&bid="+_this.sellerUin;
        try{
            addrEditCache = JSON.parse(_aeCache.getStore());
            if(addrEditCache.cf){
                switch(addrEditCache.cf){
                    case keyMap["confirmOrder"]:
                        preLink = url.confirmOrderPage;
                        if(isSaveOperate){
                            var _coCache = new store(keyMap["confirmOrder"]),
                                confirmOrderCache = JSON.parse(_coCache.getStore()) || {};
                            confirmOrderCache.adid = _this.addrId;
                            _coCache.setStore(confirmOrderCache, true);
                        }
                        break;
                }
            }
        } catch(e) {
            toPreLink();
        }
        _aeCache.delStore();
        toPreLink();
        function toPreLink(){
            location.href = preLink;
        }
    };
    /**
     * 校验表单
     */
    g.validateForm = function () {
        var _this = this, formRule, rule, node, value, valLen, pass = false;
        // input表单的校验
        for (rule in _this.formRule) {
            node = $("#" + rule);
            formRule = _this.formRule[rule];
            value = node.val().trim(), valLen = value.length;
            // 正则匹配
            if(formRule.reg.test(value)) {
                // 需要校验长度
                if((formRule.maxLen && valLen > formRule.maxLen) || (formRule.minLen && valLen < formRule.minLen)) {
                    pass = false;
                    _this.errMsg = formRule.msg+"有误";
                    break;
                } else {
                    pass = true;
                }
            } else {
                pass = false;
                _this.errMsg = formRule.msg+"有误";
                break;
            }
        }
        // 如果表单校验通过
        if(pass) {
            _this.errMsg = "";
        }
        var area = _this.areaPass, provId = area.province*1, ctid = area.city*1, regid = area.regionId*1;
        // 未选择省 || 选择了直辖市，但是没有选择区 || 选择了港澳台，但是没有选择市 || 选择了其他省份，没有选择完全的
        if(provId == -1 || (provId < 4 && regid == -1) || (provId > 30 && ctid == -1) || (provId > 4 && provId <= 30 && ctid == -1) || (provId > 4 && provId <= 30 && ctid != -1 && !_this.regionNode.hasClass("ui-d-n") && regid == -1)) {
            _this.listError = "省市区选择有误";
            pass = false;
        } else {
            _this.listError = "";
        }
        _this.setBtnStatus(pass);
    };
    // 根据用户输入，判断按钮显示状态
    g.setBtnStatus = function(show) {
        var _this = this;
        if(show) {
            _this.completeNode.removeClass("mod-pay__complete_disable");
        } else {
            _this.completeNode.addClass("mod-pay__complete_disable");
        }
    }
    /**
     * 显示错误信息
     * @param desc
     */
    g.showError = function(desc){
        bubble.showBubble({
            icon:"warn",
            text:desc || "网络错误"
        })
    }
    module.exports = g;
});
