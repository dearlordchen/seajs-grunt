define(function (require, exports) {
    var main = require("base/main"),
        promote = require("functional/promote-chose"),
        pay = require("pay/pay"),
        $ = main.$,
        dialog = main.dialog,
        util = main.util,
        bubble = main.bubble,
        dot = main.dot,
        url = main.url,
        fetch = main.request,
        keyMap = main.keyMap,
        store = main.cache,
        error = main.error;
    var params = {}, pageData, sb = bubble.showBubble, statusNode;
    // 事件处理对象
    var evtHandler = {};
    // 事件处理初始化
    evtHandler.init = function () {
        var _this = this;
        _this.evtConfig = {
            "click": {
                "viewLogistic": _this.getLogistic,
                "cancelOrder": _this.cancelOrder,
                "confirmRecv": _this.confirmRecv,
                "drawback": _this.drawback,
                "wxPay": _this.wxPay,
                "toTenpay": _this.toTenpay,
                "showPriceDetail":_this.showPriceDetail
            }
        }
    };
    evtHandler.handleEvent = function (e) {
        var node = e.target, et = node.getAttribute("et"), tag;
        // 向上找一级，找不到就算了
        if (!et) {
            node = node.parentNode;
        }
        et = node.getAttribute("et");
        // 不是对应的事件类型
        if (!et || et.indexOf(e.type) == -1) {
            return;
        }
        tag = et.split(":")[1];
        evtHandler.evtConfig[e.type][tag].call(evtHandler, node);
    };
    // 获取物流信息
    evtHandler.getLogistic = function (node) {
        node = $(node), loading = node.find("div[tag='loading']"), iNode = node.find("i"), expressNode = $("#express-path");;
        // 打开
        if(iNode.hasClass("mod-pay-list__arrow_down")) {
            // 未加载过
            if(!node.attr("loaded")) {
                // 显示正在加载状态
                loading.removeClass("ui-d-n");
                util.ajaxReq({
                    type: "get",
                    url: pageData.logistic.logisUrl,
                    dataType: "jsonp"
                }, function () {});
            } else {
                expressNode.removeClass("ui-d-n");
            }
            iNode[0].className = "mod-pay-list__arrow mod-pay-list__arrow_up";
        } else {
            // 关闭
            iNode[0].className = "mod-pay-list__arrow mod-pay-list__arrow_down";
            expressNode.addClass("ui-d-n");
        }
        window.getlogisJsonCallback = function (json) {
            node.attr("loaded", true),
            loading.addClass("ui-d-n"),
            expressNode.removeClass("ui-d-n");
            var tpl = $("#logistic-tpl").html(), html = [];
            // 能够取到物流数据
            if(json && json.retCode == 0 && json.data.traceInfos.length > 0) {
                var len = json.data.traceInfos.length - 1;
                for(var i=len;i>=0;i--) {
                    var item = json.data.traceInfos[i];
                    html.push(tpl.replace(/{#desc#}/,item.desc).replace(/{#time#}/, item.time));
                }
                expressNode.html(html.join(""));
            } else {
                expressNode.html('<div class="ui-ta-c ui-mt-medium ui-mb-medium">暂无法获取物流信息</div>');
            }
        }
    };
    // 取消订单
    evtHandler.cancelOrder = function () {
        var _this = this;
        dialog.showDialog({
            text: "确定要取消订单吗？",
            context: _this,
            leftFn: function () {
                util.ajaxReq({
                    url: url.cancelOrder,
                    dataType: "json",
                    data: {
                        dc: pageData.dealCode,
                        suin: pageData.sellerUin,
                        pt: pageData.payType == 2 ? 1 : 0
                    }
                }, function (json) {
                    var code = json.errCode;
                    sb({
                        icon: !code ? "success" : "warn",
                        text: "取消订单" + (!code ? "成功" : "失败")
                    });
                    if (!code) {
                        statusNode.html("已关闭");
                        // 隐藏整个操作区域
                        $("#operate").remove();
                    }
                }, function () {
                    showError();
                });
            }
        })
    };
    // 申请退款
    evtHandler.drawback = function () {
        var _this = this;
        dialog.showDialog({
            text: "提交退款申请后我们将尽快审核订单，若符合退款条件我们会把退款金额打回至您的支付账户，如有疑问请您通过微信与我们联系。谢谢！",
            leftBtn: "确认退款",
            rightBtn: "取消",
            context: _this,
            leftFn: function () {
                util.ajaxReq({
                    url: url.drawback,
                    data: {dc: pageData.dealCode},
                    type: "POST",
                    dataType: "json"
                }, function (json) {
                    var code = json.errCode;
                    sb({
                        icon: !code ? "success" : "warn",
                        text: "申请退款" + (!code ? "成功" : "失败")
                    });
                    // 扭转状态
                    !code && (statusNode.html("退款中"), $("#operate").html('<div class="ui-ta-c mod-pay-form__button-link">退款中...</div>'));
                }, function () {
                    showError();
                });
            }
        });
    };
    // 确认收货
    evtHandler.confirmRecv = function (node) {
        util.ajaxReq({
            url: url.confirmRecv,
            dataType: "json",
            type: "POST",
            data: {
                dc: pageData.dealCode,
                sdc: pageData.subDealCode
            }
        }, function (json) {
            var code = json.errCode;
            sb({
                icon: !code ? "success" : "warn",
                text: "确认收货" + (!code ? "成功" : "失败")
            });
            if (!code) {
                statusNode.html("交易成功");
                // 移除节点
                $(node).remove();
            }
        }, function () {
            showError();
        });
    };
    // 跳转到财付通
    evtHandler.toTenpay = function () {
        pay.handlePay({
            pc: 0,
            stockEmpty: pageData.stockEmpty,
            tenpayUrl: pageData.tenpayUrl
        });
    };
    // 微信支付
    evtHandler.wxPay = function () {
        pay.handlePay({
            pc: 1,
            stockEmpty: pageData.stockEmpty,
            dealCode:pageData.dealCode
        });
    };
    // 显示总价明细
    evtHandler.showPriceDetail = function(node) {
        node = $(node), iNode = node.find("i"), detailNode = $("#price-detail");
        // 打开
        if(iNode.hasClass("mod-pay-list__arrow_down")) {
            detailNode.removeClass("ui-d-n");
            iNode[0].className = 'mod-pay-list__arrow mod-pay-list__arrow_up';
        } else {
            detailNode.addClass("ui-d-n");
            iNode[0].className = 'mod-pay-list__arrow mod-pay-list__arrow_down';
        }
    };
    // 显示ajax错误
    function showError(desc) {
        sb({
            icon: "warn",
            text: desc || "网络错误"
        });
    }
    // 初始化函数
    function init() {
        var cache = new store(keyMap.dealDetail);
        params.dc = util.getQuery("dc");
        params.bid = util.getQuery("bid");
        // 找不到dealCode，则从缓存里拿数据
        if(!params.dc) {
            params = cache.getStore();
            try {
                params = JSON.parse(params);
            }catch(e) {
                showError("参数错误");
                error.showErrorPage();
                return;
            }
        } else {
            // 将参数写缓存，否则登录跳转回来后丢失参数
            cache.setStore(params, true);
        }
        evtHandler.init();
        fetchData();
        // 从URL中获取dealCode和bid
        bindEvent();
        //返回按钮
        $(".mod-topbar").on("click", $.proxy(goBack));

        function goBack(){
            location.href = url.myIndexPage+"&bid="+params.bid;
        }
    }
    // ajax获取页面渲染数据
    function fetchData() {
        fetch.getPageData({
            key:"dealDetail",
            data:params,
            callback:renderPage,
            loginKey:"dealDetailPage"
        });
    }
    // 渲染页面
    function renderPage(data) {
        // 把页面数据存下来
        pageData = data;
        var template = dot.template($("#content-tpl").html());
        data.payTypeText = (data.payType == 1 ? "在线支付" : "货到付款");
        data.shipFeeText = data.logistic.shipFee ? "&yen;" + (data.logistic.shipFee/100).toFixed(2) + "元" : "免运费";
        data.path = window.basePath;
        data.height = window.innerHeight+45;
        data.debug = "";
        // 渲染页面
        $("#container").html(template(data));
        // 用于各种按钮切换后的状态扭转
        statusNode = $("#deal-status");
    }
    // 利用事件冒泡绑定事件
    function bindEvent() {
        util.query("#container").addEventListener("click", evtHandler, false);
    }

    exports.dealDetail = init;
});