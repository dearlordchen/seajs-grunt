define(function(require, exports) {
    var main = require("base/main"),
        promote = require("functional/promote-chose"),
        pay = require("pay/pay"),
        $ = main.$,
        util = main.util,
        bubble = main.bubble,
        dot = main.dot,
        url = main.url,
        fetch = main.request,
        keyMap = main.keyMap,
        store = main.cache,
        error = main.error;

    var sb = bubble.showBubble,
        params = {},        // 页面参数对象
        pageData,           // 页面所需json数据
        evtHandler = {},    // 事件处理对象
        container = $("#container"),
        promoteObj = {      // 促销优惠相关对象
            reduce:0,
            couponAmount:0
        };



    // 事件处理
    evtHandler.initConfig = function() {
        var _this = this;
        _this.evtConfig = {
            "click":{
                "toPay":_this.toPay,
                "toAddr":_this.toAddr
            },
            "change":{
                "delivery":_this.deliveryChange
            },
            "touchend":{
                "coupon":_this.handleCoupon,
                "promote":_this.handlePromote
            }
        };
    };
    evtHandler.handleEvent = function(e) {
        var node = e.target, et = node.getAttribute("et"), tag;
        // 向上找一级，找不到就算了
        if (!et) {
            node = node.parentNode;
        }
        et = node.getAttribute("et");
        // 不是对应的事件类型
        if (!et || et.indexOf(e.type) == -1) {
            return;
        }
        tag = et.split(":")[1];
        evtHandler.evtConfig[e.type][tag].call(evtHandler, node);
    };
    // 跳转收货地址
    evtHandler.toAddr = function() {
        // 跳转
        location.href = url[pageData.hrefKey]+"&bid="+pageData.sellerUin+"&cf=confirmOrder"+(pageData.hasAddr ? "&addrId="+pageData.buyer.addrId : "");
    };
    // 跳转支付
    evtHandler.toPay = function() {
        // 没有收货地址
        if(!pageData.hasAddr) {
            sb({
                icon:"warn",
                text:"请确认地址"
            });
            return;
        }
        sb({
            icon:"loading",
            text:"正在加载...",
            autoHide:false
        });
        util.ajaxReq({
            url:url["pay"],
            dataType:"json",
            type:"post",
            data:{
                mt:params.mt,
                pt:params.pt,
                pageid:params.pageid||"",
                adid:pageData.buyer.addrId,
                promId:promoteObj.promId || 0,
                couponId:promoteObj.couponId || 0,
                pc:params.pc,
                comeFrom:params.comeFrom,
                ic:pageData.item[0].itemCode,
                bc:pageData.bc,
                tid:params.tid,
                attr:encodeURIComponent(pageData.attr),
                suin:pageData.sellerUin,
                shopId:sessionStorage.getItem("shopId") || ""    //业绩复算
            }
        },function(json) {
            var code = json.errCode;
            // 关闭加载效果
            bubble.closeBubble();
            if(!code) {
                // 调用支付
                pay.handlePay({
                    stockEmpty: false,
                    pc: params.pc,
                    dealCode: json.data.dealCode,
                    tenpayUrl: json.data.tenpayUrl,
                    comeFrom:params.comeFrom
                });
            } else {
                showError("下单失败");
            }
        },function() {
            bubble.closeBubble();
            showError("网络错误");
        });
    };
    // 快递
    evtHandler.deliveryChange = function(node) {
        var opt = node.options[node.selectedIndex];
        // 设置支付类型
        params.mt = opt.getAttribute("mtype");
        params.pt = opt.getAttribute("ptype");
        // 记录运费
        promoteObj.shipFee = parseInt(opt.value,10);
        promoteObj.isFreeFee = !promoteObj.shipFee;
        countPrice();
    };
    // 优惠券选择
    evtHandler.handleCoupon = function(node) {
        node = $(node);
        node.find("i").toggleClass("mod-new-product-confirm__checkbox_checked");
        // 没有选中
        if(!promoteObj.couponId) {
            promoteObj.couponId = node.attr("id");
            promoteObj.couponAmount = -parseInt(node.attr("amount"), 10);
        } else {
            promoteObj.couponId = 0
            promoteObj.couponAmount = 0;
        }
        countPrice();
    };
    // 满立减选择
    evtHandler.handlePromote = function(node) {
        node = $(node);
        node.find("i").toggleClass("mod-new-product-confirm__checkbox_checked");
        // 没有选中
        if(!promoteObj.promId) {
            promoteObj.promId = node.attr("id");
            promoteObj.reduce = -parseInt(node.attr("amount"), 10);
            promoteObj.isFreeFee = node.attr("free") == "true" ? true : false;
        } else {
            promoteObj.promId = 0;
            promoteObj.reduce = 0;
            promoteObj.isFreeFee = false;
        }
        countPrice();
    };
    function showError(desc) {
        setTimeout(function() {
            sb({
                icon:"warn",
                text:desc
            });
        },300);
    }

    function init() {
        var paramStore = new store(keyMap["confirmOrder"]), query = util.getQuery, ps = paramStore.getStore();
        // 缓存中拿不到，从URL中取
        if(!ps) {
            ps = {
                bc: query("bc"),
                attr: query("attr"),
                ic: query("ic"),
                bid: query("bid"),
                adid: query("adid"),
                comeFrom: query("comeFrom") || 0,
                hcod:query("hcod")
            };
            paramStore.setStore(ps, true);
        } else {
            ps = JSON.parse(ps);
        }
        // 检查最基本的参数商品ID
        if(!ps || !ps.ic) {
            showError("参数错误");
            error.showErrorPage();
            return;
        }
        params = ps;
        // 开始加载数据
        fetchData();
        // 初始化事件配置
        evtHandler.initConfig();
    }
    // 加载数据
    function fetchData() {
        fetch.getPageData({
            key:"confirmOrder",
            data:params,
            callback:renderPage,
            loginKey:"confirmOrderPage"
        });
    }
    // 渲染页面
    function renderPage(json) {
        pageData = json;
        var template = dot.template($("#content-tpl").html());
        json.height = window.innerHeight+45;
        json.btnText = json.wxpay ? "微信支付" : "提交订单";
        //console.log(json);
        container.html(template(json));
        // 设置参数信息
        setReqParam();
        // 获取优惠列表
        pageData.hasAddr && getPromote();
        // 事件绑定，冒泡
        bindEvent();

        $(".mod-topbar").on("click", $.proxy(goBack, json));
    }
    // 设置支付请求参数
    function setReqParam() {
        // 设置收货地址跳转链接
        pageData.hrefKey = pageData.hasAddr ? "addrListPage" : "addrEditPage";
        // 设置提交订单的参数
        params.pc = pageData.wxpay ? 1 : 0;  // 支付类型 1：微信支付；0：财付通
        if(pageData.hasAddr) {
            var firstShip = pageData.shipList[0];
            params.mt = firstShip.mtype;
            params.pt = firstShip.ptype;
            // 记录当前运费
            promoteObj.shipFee = firstShip.fee;
            // 是否免运费
            promoteObj.isFreeFee = !firstShip.fee;
        }
    }
    // 事件绑定
    function bindEvent() {
        var a = "addEventListener", c = container[0];
        c[a]("click", evtHandler, false);
        c[a]("change", evtHandler, false);
        c[a]("touchend", evtHandler, false);
    }
    // 获取优惠信息
    function getPromote() {
        var proObj = promote.init({
            couponList:pageData.conpon,
            promoteList:pageData.promote,
            comeFrom:pageData.comeFrom,
            template:$("#promote-tpl").html(),
            buyCount:pageData.bc,
            price:pageData.totalPrice
        }), html = [];
        // 有优惠信息
        if(!$.isEmptyObject(proObj)) {
            // 渲染优惠列表
            if(proObj.couponHtml) {
                html.push(proObj.couponHtml);
                promoteObj.couponId = proObj.couponId;
                promoteObj.couponAmount = proObj.couponAmount;
            }
            if(proObj.promoteHtml) {
                html.push(proObj.promoteHtml);
                promoteObj.promId = proObj.promoteId;
                promoteObj.reduce = proObj.reduce;
                promoteObj.isFreeFee = proObj.isFreeFee;
            }
            $("#promote").html('<ul class="ui-ml-large">'+html.join("")+'</ul>').removeClass("ui-d-n");
            proObj = null;
        }
        countPrice();
    }
    // 计算价格
    function countPrice() {
        // 没有收货地址
        if(!pageData.hasAddr) {
            $("#total-price").html("&yen;"+(pageData.totalPrice/100).toFixed(2));
            return;
        }
        var dis = pageData.totalPrice + promoteObj.couponAmount, price;
        // 最少0.01元原则，即使用优惠券后，如果价格低于0，则为0.01元，以分为单位
        dis < 1 && (dis = 1);
        // 再计算店铺促销金额，仍然满足0.01元的原则
        dis += promoteObj.reduce;
        dis < 1 && (dis = 1);
        // 再加上运费的价格
        price = dis + (promoteObj.isFreeFee ? 0 : promoteObj.shipFee);
        // 显示总价
        $("#total-price").html("&yen;"+(price/100).toFixed(2));
        // 设置运费节点
        $("#fee-node").html(promoteObj.isFreeFee || promoteObj.shipFee == 0 ? "(免运费)" : "(含运费)");
        // 包邮，隐藏运费列表
        if(promoteObj.isFreeFee) {
            $("#shipFee-list").addClass("ui-d-n");
        } else {
            $("#shipFee-list").removeClass("ui-d-n");
        }
    }

    function goBack(){
        location.href = document.referrer;
    }
    exports.confirmOrder = init;
});