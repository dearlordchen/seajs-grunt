define(function (require) {
    var $ = require("base/zepto"),
        dot = require("base/doT"),
        cache = require("cache/localStore"),
        login = require("login/login"),
        request = require("request/loadPageData"),
        bubble = require("ui/bubble"),
        dialog = require("ui/dialog"),
        url = require("url/urlConfig"),
        keyMap = require("url/keyConfig"),
        error = require("base/error"),
        util = require("util/util");
    return {
        "$":$,
        "dot":dot,
        "cache":cache,
        "login":login,
        "request":request,
        "bubble":bubble,
        "dialog":dialog,
        "url":url,
        "keyMap":keyMap,
        "util":util,
        "error":error
    };
});