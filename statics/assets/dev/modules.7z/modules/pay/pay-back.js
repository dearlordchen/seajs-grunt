define(function(require, exports, module) {
    var main = require("base/main"),
    	$ = main.$,
    	bubble = main.bubble;
    var g = {};
    g.init = function() {
        this.seleteNode = $(".mod-input");
        this.confirmNode = $(".mod-new-product-confirm__submit");
        this.wxId = this.confirmNode.attr("wxId");
        this.dataUrl = this.confirmNode.attr("data-url");
        this.initParams();
    };
    g.initParams = function() {
        var _this = this;
        _this.seleteNode.on("touchstart", $.proxy(this.handleSelete, this));
        _this.seleteNode.next().on("touchstart", $.proxy(this.handleSelete, this));
        _this.confirmNode.on("click", $.proxy(this.handleConfirm, this));
    };
    g.handleSelete = function() {
    	var _this = this;
        if (_this.seleteNode.hasClass("mod-input_checkbox-checked")) {
        	_this.seleteNode.removeClass("mod-input_checkbox-checked").addClass("mod-input_checkbox");
        } else {
        	_this.seleteNode.removeClass("mod-input_checkbox").addClass("mod-input_checkbox-checked");
        }
    };
    g.handleConfirm = function() {
        var _this = this;
        if (_this.seleteNode && _this.seleteNode.hasClass("mod-input_checkbox-checked")) {
            WeixinJSBridge.invoke("addContact", {
                "webtype": "1",
                "username": _this.wxId
            }, function(res) {
                if (res.err_msg != "add_contact:ok" && res.err_msg != "add_contact:added" && res.err_msg != "add_contact:cancel") {
                	bubble.showBubble({
                        icon: "warn",
                        text: "关注失败"
                    });
                }
            });
        }
        location.href = _this.dataUrl;
    }
    module.exports = g;
});