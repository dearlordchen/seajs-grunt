/**
 * @desc 全局URL配置，集中管理ajax请求以及URL跳转的地址
 */
define(function() {
    var path = window.basePath,xpath="http://weigou.qq.com/prevmbuy", debug = window.debugMode;
    var url = {
        "dealDetail":path+"/wx/deal/detailWX.xhtml",
        "drawback":path+"/wx/deal/applyRefund.xhtml",
        "confirmRecv":path+"/wx/deal/bconfirmRecv.xhtml",
        "cancelOrder":path+"/wx/deal/cancel.xhtml",
        "confirmOrder":path+"/wx/deal/comfirmWX.xhtml",
        "pay":path+"/wx/deal/makeOrder.xhtml",
        "editAddr":path + "/wx/recvAddr/save.xhtml",
        "getAddrById":path + "/wx/recvAddr/edit.xhtml",
        "getCityList":path+"/wx/recvAddr/getCityList.xhtml",
        "getAreaList":path+"/wx/recvAddr/getAreaList.xhtml",
        "setLogin":path+"/wx/auth/login.xhtml",
        "getItemDetail":path + "/wx/item/imitateWxDetail.xhtml",
        "getMyIndex":path + "/wx/my/index.xhtml",
        "getAddrList":path + "/wx/recvAddr/list.xhtml",
        "deleteAddr":path+"/wx/recvAddr/delete.xhtml",
        "detail4Saler":path+"/wx/deal/detail4Saler.xhtml",
        "favorItem":path+"/wx/guide/collect.xhtml",
        "cancelFavor":path+"/wx/guide/deleteFavorite.xhtml",
        "itemAttr":path+"/wx/item/attr.xhtml",
        "getPhotos":path+"/wx/item/photos.xhtml",
        "importAddr":path+"/wx/recvaddr/imitateWxImportAddr.xhtml",
        "qrCode":path+"/wx/guide/genarateDimCode.xhtml",
        "qrScan":path+"/wx/guide/hasScand.xhtml",
        "freeItem":path+"/wx/find/sureExchangePrize.xhtml",
        "payPage":path+"/wx/deal/pay.xhtml?showwxpaytitle=1",
        "findQrCode":path+"/wx/find/generateFreeDC.xhtml",
        "findLoopScan":path+"/wx/find/hasScand.xhtml",
        "dealDetailPage":path+"/wx/deal/dealDetail.shtml"+(debug ? "?debug=true" : ""),
        "confirmOrderPage":path+"/wx/deal/dealConfirm.shtml?showwxpaytitle=1"+(debug ? "&debug=true" : ""),
        "addrListPage":path+"/wx/addr/addr-list.shtml?showwxpaytitle=1"+(debug ? "&debug=true" : ""),
        "addrEditPage":path+"/wx/addr/addr-edit.shtml?showwxpaytitle=1"+(debug ? "&debug=true" : ""),
        "itemDetailPage":path+"/wx/item/item-detail.shtml?showwxpaytitle=1"+(debug ? "&debug=true" : ""),
        "myIndexPage":path+"/wx/my/index.shtml?showwxpaytitle=1"+(debug ? "&debug=true" : ""),
        "detail4SalerPage":path+"/wx/deal/dealDetailSaler.shtml",
        "jxItemList":path+"/wx/brand/news.xhtml?tid=test_wxweigou_cyning",
        "getCount":path+"/cn/cmdy/count.xhtml",
        "newIndex":path+"/wx/shop/index.xhtml"
    }
    return url;
})