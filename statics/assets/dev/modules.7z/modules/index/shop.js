define(function(require, exports, module) {
    var main = require("base/main"),
        $ = main.$,
        utils = main.util,
        bubble = main.bubble,
        url = main.url,
        fetch = main.request;

    var g = {}, sb = bubble.showBubble;
    // 请求收货地址列表
    g.init = function(){
        $("#ctab").on("click", $.proxy(this.tabChange,this));
        $(".go_back").on("click", $.proxy(this.goBack,this));
        this.getNum()
    };


    /**
     * getNum
     */
    g.getNum = function(){
        var buyNum = $("#buyNum")

        $.ajax({
            url:fetch.addToken(url.getCount,"ls"),
            type:"GET",
            data:{
                bid: utils.getQuery("bid"),
                ajax:true
            },
            dataType:"json",
            success: function(json) {
                // 获取数目成功
                if(!json.errCode && json.data>0) {
                    buyNum.html(json.data);
                    buyNum.removeClass("ui-d-n");
                }
            },
            error : function(){
                return;
            }
        });
    }

    /**
     * goback
     */
    g.goBack = function(){
        location.href = document.referrer;
    }

    /**
     * tab切换事件
     * @param e
     */
    g.tabChange = function(e){
        var _this = this,
            element = $(e.target),
            cclass = "mod-tab-sub__item_current",
            hclass = "ui-d-n";

        if(element.attr("data-cur")){
            if (element.hasClass(cclass)) {
                return;
            }

            element.addClass(cclass).siblings().removeClass(cclass);

            var cur = $("#"+element.attr("data-cur")),
                pre = $("#"+element.attr("data-pre"));

            cur.removeClass(hclass);
            pre.addClass(hclass);
        }

        e.preventDefault();

    }

    //url:fetch.addToken(url.deleteAddr,"ls"),


        module.exports = g;
});