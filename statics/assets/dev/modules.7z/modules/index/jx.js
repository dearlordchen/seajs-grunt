define(function(require, exports, module) {
    var main = require("base/main"),
        $ = main.$,
        utils = main.util,
        bubble = main.bubble,
        dialog = main.dialog,
        doT = main.dot,
        url = main.url,
        fetch = main.request,
        keyMap = main.keyMap,
        store = main.cache,
        error = main.error;
    var g = {}, sb = bubble.showBubble;
    // 请求收货地址列表
    g.init = function() {
        var _this = this;
        _this.initParams();
    };


    // 从url或缓存中取参数
    g.getParam = function(paramName) {
        var url = location.href,
            _aeCache = new store(keyMap["jxList"]),
            _param = utils.getQuery(paramName, url),
            aeCache;
        if (_param) {
            try {
                aeCache = JSON.parse(_aeCache.getStore()) || {};
                aeCache[paramName] = _param;
                _aeCache.setStore(aeCache, true);
            } catch (e) {}
        } else {
            try {
                aeCache = JSON.parse(_aeCache.getStore());
                if (aeCache[paramName]) {
                    _param = aeCache[paramName];
                }
            } catch (e) {}
        }
        return _param;
    };

    g.initParams = function() {
        var _this = this;
        _this.itemNum = 0, _this.itemArray = {};
        sb({
            autoHide: false
        });
        utils.ajaxReq({
            url: url.jxItemList,
            data: {
                bid: _this.getParam("bid") || '1002000325',
            },
            dataType: "json"
        }, function(json) {
            if (!json.errCode) {
                $("#page").removeClass("qb_none");
                _this.itemArray = json.data.data;
                _this.renderItemList(_this.itemNum);
            } else {
                bubble.closeBubble();
                _this.showError("网络错误");
            }
        }, function() {
            bubble.closeBubble();
            _this.showError();
            error.showErrorPage("网络错误");
        });
        _this.bindEvent();
    };

    //渲染商品
    g.renderItemList = function(nowItemNum) {
        var _this = this,
            dotTpl = doT.template($("#item-tpl").html()),
            ulNode = $("#item-list"),
            jsonData = _this.itemArray,
            totalCount = jsonData.length,
            _nowitemNum = nowItemNum,
            itemArr = [];
        for (var i = _nowitemNum, j = i + 5; i < j && (_nowitemNum + 1) <= totalCount; i++) {
            jsonData[i].index = _nowitemNum;
            itemArr.push(jsonData[i]);
            _nowitemNum++;
        }
        _this.itemNum = _nowitemNum;
        ulNode.append(dotTpl(itemArr));
        bubble.closeBubble();
        if (_this.itemNum == totalCount) {
            $("#more").addClass('qb_none');
            $(window).off("scroll");
        }
        $(".mod-discount__item").on("click", function(e) {
            var node = $(e.target);
            while (!node.hasClass("mod-discount__item")) {
                node = node.parent();
            }
            location.href = node.attr("data-url");
        });
    };

    g.bindEvent = function() {
        var _this = this;
        //加载更多
        //$("#more").on("click", $.proxy(this.loadMoreItem, this));
        $(window).on("scroll", $.proxy(this.doScroll, this));
        $(".mod-topbar__right").on("touchstart", function(e) {
            var node = $(e.target);
            while (!node.hasClass("mod-topbar__right")) {
                node = node.parent();
            }
            location.href = url.myIndexPage+"&bid="+(_this.getParam("bid")||'1002000325');
        });
    };
    g.doScroll = function () {
    	var _this = this;
        var st = $(window).scrollTop();
        if(st>=($(document).height()-$(window).height())){
        	_this.loadMoreItem();
        }
    }
    g.loadMoreItem = function() {
//        sb({
//            autoHide: false
//        });
        this.renderItemList(this.itemNum);
    }

    g.showError = function(desc) {
        setTimeout(function() {
            sb({
                icon: "warn",
                text: desc || "网络错误"
            });
        }, 250);
    }

    module.exports = g;
});