define(function(require, exports, module) {
    var main = require("base/main"),
        $ = main.$,
        utils = main.util,
        bubble = main.bubble,
        dialog = main.dialog,
        doT = main.dot,
        url = main.url,
        fetch = main.request,
        keyMap = main.keyMap,
        store = main.cache,
        error = main.error;
    var g = {}, sb = bubble.showBubble;
    // 请求收货地址列表
    g.init = function(){
        var _this = this;
        _this.windowHeight = window.innerHeight + 45;
        _this.initParams();
    };

    /**
     * 校验url
     */
    g.checkUrl = function(){
        var _this = this;
        _this.sellerUin = _this.getParam("bid");
        if(!_this.sellerUin){
            _this.showError("链接错误");
            return false;
        }
        return true;
    };

    // 从url或缓存中取参数
    g.getParam = function (paramName){
        var url = location.href,
            _aeCache = new store(keyMap["addrList"]),
            _param = utils.getQuery(paramName, url),
            aeCache;
        if(_param){
            try{
                aeCache = JSON.parse(_aeCache.getStore()) || {};
                aeCache[paramName] = _param;
                _aeCache.setStore(aeCache, true);
            } catch(e) {
            }
        } else {
            try{
                aeCache = JSON.parse(_aeCache.getStore());
                if(aeCache[paramName]){
                    _param = aeCache[paramName];
                }
            } catch(e) {
            }
        }
        return _param;
    };

    g.initParams = function() {
        var _this = this;
        _this.itemNum = 0;      //目前商品数量

        //old params
        var _this= this;
        _this.itemCache = [];
        _this.curIndex = 0;
        _this.curIc = "";
        _this.curImg="";
        _this.tid = utils.getQuery("tid");

        _this.isFocus = window.isFocus=="true" ? true : false;
        _this.wxId = window.wxId;

        // 购买数量
        _this.buyNum = 1;
        // 获取当前的库存数量
        _this.curStock = 0;
        // 存放已选择的属性，用于属性关系互斥的判断
        _this.matchProperty = [];
        // 已经选择的属性
        _this.selectedCount = 0;
        // sku组合列表数组
        _this.propList = [];
        // 已选择的属性(格式化的)
        _this.buyProperty = "";
        // 提示错误信息
        _this.errorMsg = "";

        _this.dialogNode = $("#dialog");
        _this.maskNode = $("#mask");
        _this.itemContainer = $("#item-container");
        _this.itemTpl = $("#attr-tpl").html();
        _this.confirmNode = $("#confirm");
        _this.sellerUin = _this.getParam("bid");

        //$("#more").addClass('qb_none');
        _this.renderItemList(_this.itemNum);

    };
    
    //渲染商品
    g.renderItemList = function(nowItemNum) {
        var _this = this,
            dotTpl = doT.template($("#item-tpl").html()),
            ulNode = $("#item-list"),
            jsonData = itemArray["1"],
            totalCount = jsonData.length,
            _nowitemNum = nowItemNum,
            itemArr = [];
        for (var i = _nowitemNum, j = i + 2; i < j && (_nowitemNum + 1) <= totalCount; i++) {
            jsonData[i].index = _nowitemNum;
            itemArr.push(jsonData[i]);
            _nowitemNum++;
        }
        _this.itemNum = _nowitemNum;
//        if(_this.itemNum == totalCount){
//            $("#more").addClass('qb_none');
//        }
        //bubble.closeBubble();
        ulNode.append(dotTpl(itemArr));
        _this.bindEvent();
    };
    
    g.bindEvent = function(){
        $(window).on("bubble:show",function() {
            window.bubbleStatus = true;
        });
        $(window).on("bubble:close",function() {
            window.bubbleStatus = false;
        });
        //加载更多
        //$("#more").on("click", $.proxy(this.loadMoreItem,this));
        $(window).on("scroll", $.proxy(this.doScroll, this));
        //打开微信图片
        $(".mod-subject__slider-image").on("click", $.proxy(this.handleOpenImgs,this));
        //按钮区域事件集合
        $("div.mod-subject__operate").on("click", $.proxy(this.handleOper,this));
        //一键购买
        //$(".mod-subject__operate-button").on("click", $.proxy(this.handleOpenDialog, this));
        //返回按钮
        $(".mod-my-head__operate").on("click", $.proxy(this.goBack));
        $(".mod-topbar").on("click", $.proxy(this.goBackRefer));
        $(".mod-my-head__cover").on("click", $.proxy(this.goBackRefer,this));

        //关注
        $(".mod-my-head__follow").on("touchstart", $.proxy(this.handleWatch));
        //相册
       // $("[ev=photo]").on("touchstart", $.proxy(this.photoImgs, this));
        //属性
        //$("[ev=attr]").on("touchstart", $.proxy(this.handleAttr, this));

    };


    g.doScroll = function () {
        var _this = this;
        var st = $(window).scrollTop();
        if(st>=($(document).height()-$(window).height())){
            _this.loadMoreItem();
        }
    }

    g.loadMoreItem = function(){
//        sb({
//            autoHide: false
//        });
        this.renderItemList(this.itemNum);
    }





    /**
     *关注
     */
    g.handleWatch = function(e){
        WeixinJSBridge && WeixinJSBridge.invoke("addContact", {
            "webtype": "1",
            "username": window.sellerWxid
        }, function(res) {
            if (res.err_msg == "add_contact:ok" || res.err_msg == "add_contact:added" ) {
                $(".mod-my-head__follow").html("已关注");
            }
        });
    }

    /**
     * 大图
     * @param e
     */
    g.handleOpenImgs = function(e){
        if(window.bubbleStatus){
            return;
        }
        var node = $(e.target),imgs = node.attr("data-imgs").split("^");
       imgs && showPic(imgs);
        function showPic(list) {
            list && WeixinJSBridge && WeixinJSBridge.invoke('imagePreview',{
                    'current':list[0],
                    'urls':list}
            );
        }
    };


    g.handleOper = function(e){
        if(window.bubbleStatus){
            return;
        }
        var _this = this,
            s= $(e.target),
            node = s;


        while(!node.attr("data-index")){
            node = node.parent();
        }

        switch (s.attr("ev")){
            case "attr":
                _this.curIndex = parseInt(node.attr("data-index"),10);
                _this.curIc = node.attr("item-id");
                _this.curImg = node.attr("item-img").replace(/.jpg/i,".80x80.jpg");
                _this.handleAttr();
                break;
            case "photo":
                _this.curIc = node.attr("item-id");
                _this.photoImgs();
                break;
            case "buy":
                _this.curIndex = parseInt(node.attr("data-index"),10);
                _this.curIc = node.attr("item-id");
                _this.curImg = node.attr("item-img").replace(/.jpg/i,".80x80.jpg");
                _this.handleOpenDialog();
                break;
        }

        e.stopPropagation();

    }

    /**
     * 相册
     * @param e
     */
    g.photoImgs = function(){
        if(window.bubbleStatus){
            return;
        }
        var _this = this;
        sb({autoHide:false});
        utils.ajaxReq({
            url: url.getPhotos,
            data: {ic: _this.curIc, t: +new Date()},
            dataType: "json"
        }, function (json) {
            bubble.closeBubble();
            if (!json.errCode) {
                var imgs = json.data;
                imgs && showPic(imgs);
            }
        }, function () {
            bubble.closeBubble();
            setTimeout(function() {
                _this.showError();
            }, 250);
        });


        function showPic(list) {
            list && WeixinJSBridge && WeixinJSBridge.invoke('imagePreview',{
                    'current':list[0],
                    'urls':list}
            );
        }
    };

    /**
     * 属性弹窗事件
     */
    g.handleAttr = function () {
        var _this = this;
        // 有打开过浮层，直接拿缓存
        if (!_this.itemCache[_this.curIndex]) {
            sb({autoHide:false});
            utils.ajaxReq({
                url: url.itemAttr,
                data: {ic: _this.curIc, t: +new Date()},
                dataType: "json"
            }, function (json) {
                bubble.closeBubble();
                if (!json.errCode) {
                    var data = json.data;
                    data.imgUrl = _this.curImg;
                    data.itemPrice = (data.itemPrice / 100).toFixed(2);
                    _this.itemCache[_this.curIndex] = data;


                    _this.renderAttr();
                    _this.openDialog();
//                    _this.openAttr();
                } else {
                    setTimeout(function() {
                        _this.showError("请求出错");
                    }, 250);
                }
            }, function () {
                bubble.closeBubble();
                setTimeout(function() {
                    _this.showError();
                }, 250);
            });
        } else {
            _this.renderAttr();
            _this.openDialog();
//            _this.openAttr();
        }
    };

    /**
     * 渲染属性浮层
     */
    g.renderAttr = function(){

        var _this = this;
        var dotTpl = doT.template($("#info-tpl").html());
        var attrs = _this.itemCache[_this.curIndex].attrList;
        _this.itemContainer.html(dotTpl(attrs));
        $(".mod-new-product-detail__title").on("click",$.proxy(_this.handleCloseDialog, _this));
        // 非android或者android4.0以上系统
        if(!$.os.android || parseInt($.os.version) >= 4) {
            $("#inner-container").css({
                "height":($.os.android ? _this.windowHeight : window.innerHeight) - 158
            });
        } else {
            $("#inner-container").css({
                "height":($.os.android ? _this.windowHeight : window.innerHeight) - 156
            });
        }

        WeixinJSBridge && WeixinJSBridge.invoke('hideToolbar', function(res) {});
    }


    /**
     * 打开浮层事件
     * @param e
     */
    g.handleOpenDialog = function () {
        if (window.bubbleStatus) {
            return;
        }
        //if(node.hasClass("mod-chose__property_disabled")) {return;}
        var _this = this;
        // 活动期间免单的
//        if(pageData.prizeId != -1) {
//            _this.exchangeFree(node);
//            return;
//        }
//        var _this = this,node = $(e.target),index = parseInt(node.attr("data-index"),10);
//        _this.curIndex = index;


        // 参数恢复
        // 购买数量
        _this.buyNum = 1;
        // 获取当前的库存数量
        _this.curStock = 0;
        // 存放已选择的属性，用于属性关系互斥的判断
        _this.matchProperty = [];
        // 已经选择的属性
        _this.selectedCount = 0;
        // sku组合列表数组
        _this.propList = [];
        // 已选择的属性(格式化的)
        _this.buyProperty = "";
        // 提示错误信息
        _this.errorMsg = "";
        // 限购数量
        _this.buyLimit = null;

        _this.renderDialogPage();

    };


    /**
     * 浮层弹出
     */
    g.openDialog = function () {
        var _this = this;
        // android
        if ($.os.android && parseInt($.os.version, 10) < 4) {
            _this.dialogNode.css({"top": "0px", "position": "relative"});
        } else {
            _this.dialogNode.css({"top": _this.windowHeight, "height": ($.os.android ? _this.windowHeight : window.innerHeight) - 10, "position": "fixed"});
        }
        // android4以下系统部使用动画
        if ($.os.android && parseInt($.os.version) < 4) {
            //_this.pageNode.addClass("ui-d-n");
            _this.dialogNode.css({
                "position": "relative",
                "top": "0px",
                "z-index": 999
            }).removeClass("ui-d-n");
            _this.maskNode.removeClass("ui-d-n");
        } else {
            _this.dialogNode.removeClass("ui-d-n");
            _this.maskNode.removeClass("ui-d-n");
            _this.dialogNode.animate({
                "-webkit-transform": "translate3d(0px," + -_this.windowHeight + "px,0px)"
            }, 300, "linear", function () {
            });
        }
    };
    /**
     * 浮层隐藏
     */
    g.handleCloseDialog = function () {
        var _this = this;
        // android4以下系统部使用动画
        if ($.os.android && parseInt($.os.version) < 4) {
            _this.maskNode.addClass("ui-d-n");
            _this.dialogNode.addClass("ui-d-n");
            //_this.pageNode.removeClass("ui-d-n");
        } else {

            //_this.dialogNode.addClass("ui-d-n");
            _this.dialogNode.animate({
                "-webkit-transform": "translate3d(0px,0px,0px)"
            }, 300, "linear", function () {
                _this.maskNode.addClass("ui-d-n");
            });
        }
    };

    /**
     * 渲染浮层内容
     */
    g.renderDialogPage = function () {
        var _this = this;
        // 有打开过浮层，直接拿缓存
        if (!_this.itemCache[_this.curIndex]) {
            sb({autoHide:false});
            utils.ajaxReq({
                url: url.itemAttr,
                data: {ic: _this.curIc, t: +new Date()},
                dataType: "json"
            }, function (json) {
                bubble.closeBubble();
                if (!json.errCode) {
                    var data = json.data;
                    data.imgUrl = _this.curImg;
                    data.itemPrice = (data.itemPrice / 100).toFixed(2);
                    _this.itemCache[_this.curIndex] = data;

                    _this.buyLimit = parseInt(data.buyLimit);
                    _this.curStock = !data.totalStock ? 0 : parseInt(data.totalStock);
                    $.each(data.availSku, function (key) {
                        _this.propList.push(key);
                    });
                    _this.renderDialogProp();
                    _this.openDialog();
                } else {
                    setTimeout(function() {
                        _this.showError("请求出错");
                    }, 250);
                }
            }, function () {
                bubble.closeBubble();
                setTimeout(function() {
                    _this.showError();
                }, 250);
            });
        } else {
            _this.renderDialogProp();
            _this.openDialog();
        }
    };
    /**
     * 渲染浮层中的属性
     */
    g.renderDialogProp1 = function () {
        var _this = this,
            data = _this.itemCache[_this.curIndex],
            skus = data.sku, errNotify = [], matchObj = {};
        data.propList = [];

        skus.forEach(function (sku, index) {
            var obj = {pName: sku.pName, pList: []};
            sku.pList.forEach(function (it) {
                var temp = {};
                temp.key = sku.pName + ":" + it;
                temp.sname = it;
                temp.className = sku.pList.length === 1 ? "mod-chose__property_current" : '';
                obj.pList.push(temp);
            });
            data.propList.push(obj);
            if (sku.pList.length == 1) {
                // 目的是只保存第一个只有一个属性的属性项作为后续的匹配
                if (!matchObj["key"]) {
                    matchObj["key"] = sku.pName + ":" + sku.pList[0];
                    matchObj["index"] = index;
                    matchObj["propName"] = sku.pName;
                }
                _this.matchProperty[index] = sku.pName + ":" + sku.pList[0];
                _this.selectedCount++;
            } else {
                errNotify.push(sku.pName);
            }
        });
        _this.errorMsg = "请选择" + errNotify.join("/");
        // 非android或者android4.0以上系统
        data.innerStyle = 'height:' + (($.os.android ? _this.windowHeight : window.innerHeight) - 158) + 'px;';
        if (!$.os.android || parseInt($.os.version) >= 4) {
            data.innerStyle += 'overflow-y:scroll;';
        }
        //data.imgSrc = pageData.itemPics[0];
        $("#item-container").html(_this.itemTpl(data));

        // 展示属性的节点列表
        _this.pNodeList = $(".mod_property");
        _this.buyNode = $("#weixin-buy");
        //商品缺货
        if (_this.itemCache[_this.curIndex].itemState != "2") {
            _this.buyNode.html("暂时缺货").addClass("btn_disabled");
        }
        // 存在单个属性的情况
        matchObj["key"] && _this.loopProp(matchObj["key"], matchObj["index"], matchObj["propName"]);
        matchObj = null;
        $(".mod-new-product-detail__title").on("tap", $.proxy(_this.handleCloseDialog, _this));
        $(".mod_property span").on("tap", $.proxy(_this.handleProperty, _this));
        $("#buyNum").on("input", $.proxy(_this.handleInput, _this));
        $(".minus").on("tap", $.proxy(_this.handleBtnNum, _this));
        $(".plus").on("tap", $.proxy(_this.handleBtnNum, _this));
        _this.buyNode.on("tap", $.proxy(_this.handleBuy, _this));
    }


    /**
     * 初始化页面：属性
     */
    g.renderDialogProp = function(){
        var _this = this,
            skus = _this.itemCache[_this.curIndex].sku,
            propTpl = $("#prop-tpl").html(),
            sp = '<span data-value="{#key#}" class="mod-chose__property {#className#}">{#optionName#}</span>',
            pListHtml = [], errNotify = [], matchObj = {};
        skus.forEach(function (sku, index) {
            var pHtml = [];
            sku.pList.forEach(function (it) {
                var key = sku.pName+":"+it, temp;
                temp = sp.replace(/{#key#}/, key).replace(/{#optionName#}/,it).replace(/{#className#}/,sku.pList.length === 1 ? "mod-chose__property_current" : '');
                pHtml.push(temp);
            });
            if(sku.pList.length == 1) {
                // 目的是只保存第一个只有一个属性的属性项作为后续的匹配
                if(!matchObj["key"]) {
                    matchObj["key"] = sku.pName+":"+sku.pList[0];
                    matchObj["index"] = index;
                    matchObj["propName"] = sku.pName;
                }
                _this.matchProperty[index] = sku.pName+":"+sku.pList[0];
                _this.selectedCount++;
            } else {
                errNotify.push(sku.pName);
            }
            pListHtml.push(propTpl.replace(/{#index#}/, index).replace(/{#pName#}/g, sku.pName).replace(/{#pList#}/, pHtml.join("")));
        });
        _this.errorMsg = "请选择"+errNotify.join("/");
        _this.itemContainer.html( utils.strReplace(_this.itemTpl,_this.itemCache[_this.curIndex]).replace(/{#propList#}/g,pListHtml.join("")));
        // 展示属性的节点列表
        _this.pNodeList = $(".mod-chose__detail");
        _this.buyNode = $("#weixin-buy");
        //商品缺货
        if(_this.itemCache[_this.curIndex].itemState != "2"){
            _this.buyNode.html("暂时缺货").addClass("btn_disabled");
        }
        // 存在单个属性的情况
        matchObj["key"] && _this.loopProp(matchObj["key"], matchObj["index"], matchObj["propName"]);
        matchObj = null;

        $(".mod-new-product-detail__title").on("click",$.proxy(_this.handleCloseDialog, _this));
        $(".mod-chose__detail span").on("touchend", $.proxy(_this.handleProperty, _this));
        $("#buyNum").on("input", $.proxy(_this.handleInput, _this));
        $(".mod-chose__quantity-minus").on("click", $.proxy(_this.handleBtnNum, _this));
        $(".mod-chose__quantity-plus").on("click", $.proxy(_this.handleBtnNum, _this));
        _this.buyNode.on("click", $.proxy(_this.handleBuy, _this));
        // 非android或者android4.0以上系统
        if(!$.os.android || parseInt($.os.version) >= 4) {
            $("#inner-container").css({
                "height":($.os.android ? _this.windowHeight : window.innerHeight) - 158,
                "overflow-y":"scroll"
            });
        } else {
            $("#inner-container").css({
                "height":($.os.android ? _this.windowHeight : window.innerHeight) - 156,
                "overflow-y":"scroll"
            });
        }
    }

    /**
     * 购买支付
     */
    g.handleBuy = function () {
        if (window.bubbleStatus) {
            return;
        }

        /*var callback = arguments.callee;
        // 未关注商家
        if (!pageData.focus) {
            focus.focusInit("购买商品，需要关注该商户，是否立即关注?", pageData.bidWxId, function () {
                pageData.focus = true;
                // 调用一下自己，继续下单
                callback();
            });
            return;
        }*/
        var _this = this;
        if (_this.buyNode.hasClass("btn_disabled")) {
            return;
        }
        if (_this.itemCache[_this.curIndex].sku.length >0 && !_this.buyProperty) {
            _this.showError(_this.errorMsg);
            return;
        }

        sb({text:"努力加载中...",autoHide:false});
        var _coCache = new store(keyMap["confirmOrder"]);
        _coCache.setStore({
            "attr": _this.buyProperty,
            "bc": _this.buyNum,
            "ic": _this.curIc,
            "bid": _this.sellerUin,
            "tid":_this.tid,
            "hcod": 1,
            "comeFrom": 0
        }, true);
        location.href = url.confirmOrderPage;
    }
    /**
     * 绑定属性筛选事件
     * @param e
     */
    g.handleProperty = function (e) {
        if (window.bubbleStatus) {
            return;
        }
        var p = $(e.target);
        if (p.hasClass("mod-chose__property_current") || p.hasClass("mod-chose__property_disabled") || p.attr("tag") || p[0].tagName.toUpperCase()=="INPUT") {
            return;
        }
        p.addClass("mod-chose__property_current").siblings().removeClass("mod-chose__property_current");
        var parent = p.parent();
        this.loopProp(p.attr("data-value"), parent.attr("index"), parent.attr("skuName"));
    };
    /**
     * 循环属性项
     * @param key   选中的属性值 颜色:红色
     * @param index 序号
     * @param propName  属性名 颜色
     */
    g.loopProp = function (key, index, propName) {
        var availAttr = [], flag = true, _this = this, cache = _this.itemCache[_this.curIndex];
        // 选择的是颜色属性，展示对应的图片
        /*if(propName == "颜色" && cache.colorImage[key]) {
            $("#property-img").attr("src", cache.colorImage[key]);
        }*/
        // 统计已选择的数量，不存在的时候记录
        if (!_this.matchProperty[index]) {
            _this.selectedCount++;
        }
        _this.matchProperty[index] = key;
        availAttr[index] = key;
        $.each(_this.itemCache[_this.curIndex].sku, function (index, item) {
            var pName = item.pName, pList = item.pList, skuGroup, propArr, node = _this.pNodeList.eq(index), spans = node.find("span");
            if (pName !== propName) {
                $.each(pList, function (seq, prop) {
                    skuGroup = pName + ":" + prop;
                    propArr = [];
                    propArr.push(skuGroup);
                    $.each(_this.matchProperty, function (k, v) {
                        if (v && v.match(/.*(?=:)/)[0] != pName) {
                            propArr.push(v);
                        }
                    });
                    $.each(_this.propList, function (tk, tv) {
                        flag = propArr.every(function (it) {
                            return tv.indexOf(it) !== -1;
                        });
                        if (flag) {
                            return false;
                        }
                    });
                    flag ? spans.eq(seq).removeClass("mod-chose__property_disabled") : spans.eq(seq).addClass("mod-chose__property_disabled");
                });
            }
        });
        _this.statisticSelected();
    };
    /**
     * 统计已选择的属性
     */
    g.statisticSelected = function () {
        var _this = this, stock, left;
        // 没有选完
        if (_this.selectedCount < _this.itemCache[_this.curIndex].sku.length) {
            return;
        }
        var rule = _this.matchProperty.join("|");
        _this.buyProperty = rule;
        stock = _this.itemCache[_this.curIndex].availSku[rule];

        if (stock) {
            $("#buyNum").val(1);
            left = stock.stockCount;
            $("#stock-num").html("剩余"+left+"件");
            _this.curStock = parseInt(left, 10);
            if(_this.curStock==0){
                _this.buyNode.html("暂时缺货").addClass("btn_disabled");
            }else{
                _this.buyNode.html("立即购买").removeClass("btn_disabled");
            }
            $("#price").html("&yen;" + (stock.stockPrice / 100).toFixed(2));
        }
    };
    /**
     * 购买数量事件处理
     * @param e
     */
    g.handleInput = function (e) {
        var inputNode = $(e.target), val = inputNode.val(), _this = this;
        if (val && isNaN(val)) {
            inputNode.val(1);
            _this.showError("只能输入数字");
        } else if (!val || val <= 0) {
            inputNode.val(1);
            _this.showError("至少购买一件");
        } else if (/\d+\.\d*/.test(val)) {
            inputNode.val(parseInt(val, 10));
            _this.showError("只能输入整数");
        } else if (val > this.curStock) {
            _this.showError("超出库存限制");
            inputNode.val(this.curStock);
            this.buyNum = this.curStock;
        } else if (this.buyLimit && val > this.buyLimit) {
            _this.showError("超出限购数量");
            inputNode.val(this.buyLimit);
            this.buyNum = this.buyLimit;
        } else if (val > 50) {
            _this.showError("超出数量");
            if (this.curStock > 50) {
                inputNode.val(50);
                this.buyNum = 50;
            } else {
                inputNode.val(this.curStock);
                this.buyNum = this.curStock;
            }
        } else {
            this.buyNum = val;
        }
    };
    /**
     * 增减两个按钮事件
     */
    g.handleBtnNum = function (e) {
        if (window.bubbleStatus) {
            return;
        }
        var _this = this, node = $(e.target), tag = node.attr("tag"), inputNode = $("#buyNum"), val = inputNode.val() * 1;
        if (!val) {
            return;
        } else if (isNaN(val)) {
            inputNode.val(1);
        } else if (val == 1 && tag == "sub") {
            _this.showError("至少购买一件");
            return;
        } else if (tag == "add") {
            if (this.curStock > 50 && val >= 50) {
                _this.showError("超出数量");
                return;
            } else if (this.buyLimit && val == this.buyLimit) {
                _this.showError("超出限购数量");
                return;
            } else if (val == this.curStock) {
                _this.showError("超出库存限制");
                return;
            }
        }
        val = tag == "sub" ? val - 1 : val * 1 + 1;
        inputNode.val(val);
        this.buyNum = val;
    };

    g.showError = function(desc) {
        setTimeout(function() {
            sb({icon:"warn",text:desc||"网络错误"});
        }, 250);
    }

    g.goBack = function(){
        location.href = window.basePath+"/wx/index/index.shtml?bid=1002000325";
    }

    g.goBackRefer = function(){
        var _this = this;
        location.href = url.newIndex+"?bid="+(_this.sellerUin||1002000325);

    }
    module.exports = g;
});