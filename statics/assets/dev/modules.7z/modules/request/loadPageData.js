/**
 * 加载页面数据
 *  @param key 配置的URL
 *         data 需要请求的数据
 *         callback function
 *         context 上下文
 */
define(function (require, exports) {
    var $ = require("base/zepto"),
        url = require("url/urlConfig"),
        util = require("util/util"),
        bubble = require("ui/bubble"),
        login = require("login/login"),
        error = require("base/error");
    var sb = bubble.showBubble;

    function loadData(config) {
        var option = {
            key: "",         // 要请求的URL key
            data: "",        // 请求参数
            callback: function () {},      // 回调函数
            context: "",                 // 上下文
            loginKey: "",                 // 未登录时跳转回调页面key
            addToken: false,           //url是否加token
            tokenType: 'ls'            //token类型
        };
        if (!config) {
            return;
        }
        $.extend(option, config);
        // 显示loading
        sb({autoHide: false});
        //option.data.t?option.data.t = +new Date():"";
        // 判断URL的ticket参数
        if (util.getQuery("ticket")) {
            setLogin(option.data.bid, load);
        } else {
            load();
        }
        function load() {
            sendReq(option.key, option.data, option.addToken, option.tokenType, function (json) {
                bubble.closeBubble();
                var code = json.errCode;
                if (!code) {
                    // 调用回调函数
                    if (option.context) {
                        option.callback.call(option.context, json.data);
                    } else {
                        option.callback(json.data);
                    }
                } else if (code == 999) {
                    // 跳转登录
                    login.jumpLogin(url[option.loginKey]);
                } else {
                    error.showErrorPage();
                    showError("请求遇到错误");
                }
            }, function () {
                bubble.closeBubble();
                showError("网络错误");
                error.showErrorPage();
            });
        }
    }

    function sendReq(key, data, aToken, tokenType, callback, error) {
    	//var newUrl = addToken?addToken(url[key],tokenType):url[key];
        util.ajaxReq({
            url: aToken?addToken(url[key],tokenType):url[key],
            dataType: "json",
            data: data
        }, callback, error);
    }

    // 显示错误信息
    function showError(desc) {
        setTimeout(function () {
            sb({
                icon: "warn",
                text: desc
            });
        }, 300);
    }

    // 设置登录cookie
    function setLogin(bid, callback) {
        var ticket = util.getQuery("ticket");
        if (ticket) {
            sendReq("setLogin", {
                wxTicket: ticket,
                wgBid: bid
            }, function (json) {
                // 设置cookie成功
                if (!json.errCode) {
                    // 改变页面的URL，丢掉ticket参数
                    util.setCookie("wk2", json.data.wk2, 0.03125, "/", ".weigou.qq.com");
                    util.setCookie("bid", bid, 0.03125, "/", ".weigou.qq.com");
                    util.setCookie("commid", json.data.commid, 0.03125, "/", ".weigou.qq.com");
                    util.setCookie("crmuin", json.data.uin, 0.03125, "/", ".weigou.qq.com");
                    history.replaceState({}, '', location.href.split("?")[0]);
                    callback();
                } else {
                    error.showErrorPage();
                }
            }, function () {
                showError("网络错误");
                error.showErrorPage();
            });
        } else {
            callback();
        }
    }
    
 // 检测是否存在g_tk
    function hasToken(url) {
        var reg = /(\?|&)g_tk=\d+(?=(&|$))/;
        return reg.test(url);
    }
    function addToken(url,type){
        if(hasToken(url)) {return url;}
        //type标识请求的方式,ls表loadscript，j132标识jquery，j126标识base，lk标识普通链接,fr标识form表单,ow打开新窗口
        var token=getToken();
        //只支持http和https协议，当url中无协议头的时候，应该检查当前页面的协议头
        if(url=="" || (url.indexOf("://")<0?location.href:url).indexOf("http")!=0){
            return url;
        }
        if(url.indexOf("#")!=-1){
            var f1=url.match(/\?.+\#/);
            if(f1){
                var t=f1[0].split("#"),newPara=[t[0],"&g_tk=",token,"&g_ty=",type,"#",t[1]].join("");
                return url.replace(f1[0],newPara);
            }else{
                var t=url.split("#");
                return [t[0],"?g_tk=",token,"&g_ty=",type,"#",t[1]].join("");
            }
        }
        //无论如何都把g_ty带上，用户服务器端判断请求的类型
        return token==""?(url+(url.indexOf("?")!=-1?"&":"?")+"g_ty="+type+"&serialNo="+parseInt(Math.random()*20000, 10)):(url+(url.indexOf("?")!=-1?"&":"?")+"g_tk="+token+"&g_ty="+type+"&serialNo="+parseInt(Math.random()*20000, 10));
    }
    function getCookie(name) {
        //读取COOKIE
        var reg = new RegExp("(^| )" + name + "(?:=([^;]*))?(;|$)"), val = document.cookie.match(reg);
        return val ? (val[2] ? unescape(val[2]).replace(/(^")|("$)/g,"") : "") : null;
    };
    function getToken(){
        var sid=getCookie("_T_AID_"),
            token=sid==null?"":time33(sid);
        return token;
    };
    function time33(str){
        //哈希time33算法
        for(var i = 0, len = str.length,hash = 5381; i < len; ++i){
            hash += (hash << 5) + str.charAt(i).charCodeAt();
        };
        return hash & 0x7fffffff;
    }

    exports.getPageData = loadData;
    exports.addToken = addToken;
});
